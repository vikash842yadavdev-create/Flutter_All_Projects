import 'package:flutter/material.dart';
import 'package:espenso/features/config/app_constants.dart';
import 'package:espenso/features/config/helper.dart';

class AppTheme {
  final ThemeData primaryTheme = ThemeData(
    progressIndicatorTheme: ProgressIndicatorThemeData(
      color: AppColors.primary,
    ),
    textTheme: const TextTheme(
      displaySmall: TextStyle(
        color: Colors.black,
        fontWeight: FontWeight.w400,
        fontSize: 12,
      ),
      bodySmall: TextStyle(
        color: Colors.black,
        fontWeight: FontWeight.w400,
        fontSize: 14,
      ),
      bodyMedium: TextStyle(
        color: Colors.black,
        fontWeight: FontWeight.w400,
        fontSize: 16,
      ),
      bodyLarge: TextStyle(
        color: Colors.black,
        fontWeight: FontWeight.w600,
        fontSize: 18,
      ),
      displayLarge: TextStyle(
        color: Colors.black,
        fontWeight: FontWeight.w400,
        fontSize: 20,
      ),
      headlineSmall: TextStyle(
        color: Colors.black,
        fontWeight: FontWeight.w600,
        fontSize: 22,
      ),
      headlineMedium: TextStyle(
        color: Colors.black,
        fontWeight: FontWeight.w600,
        fontSize: 24,
      ),
      headlineLarge: TextStyle(
        color: AppColors.black,
        fontWeight: FontWeight.w700,
        fontSize: 32,
        fontFamily: AppConstants.rajdhani,
      ),
    ),
    fontFamily: AppConstants.oxanium,
    scaffoldBackgroundColor: AppColors.primary,
    colorScheme: const ColorScheme.light(primary: AppColors.black),
  );

  ThemeData getTheme() {
    return primaryTheme;
  }
}
