import 'package:espenso/features/config/assets.dart';
import 'package:espenso/features/config/helper.dart';
import 'package:espenso/features/modules/common_widgets/common_small_widgets/custom_headerbar_widget.dart';
import 'package:espenso/features/modules/common_widgets/common_text_widget.dart';
import 'package:espenso/features/modules/wallet_module/data/models/bill_model.dart';
import 'package:espenso/features/modules/wallet_module/presentation/controller/wallet_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
class PaymentsuccessView extends StatefulWidget {
  final BillModel item;
  const PaymentsuccessView({super.key, required this.item});

  @override
  State<PaymentsuccessView> createState() => _PaymentsuccessViewState();
}

class _PaymentsuccessViewState extends State<PaymentsuccessView> {
  @override
  Widget build(BuildContext context) {
    final walletController = Get.find<WalletController>();

    final paymentMethod = walletController.selectedPaymentMethod.value;

    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage(Assets.imgBackground2),
            fit: BoxFit.cover,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            children: [
              40.pixelH,
              CustomHeaderBar(
                onLeadingTap: () {
                  Get.find<WalletController>().currentView.value =
                      WalletAllView.billPaymentView;
                },
                title: "Transaction Details",
                actionIcon: Icons.more_horiz,
              ),
              50.pixelH,

              CircleAvatar(
                backgroundColor: AppColors.transparent,
                radius: 20,
                backgroundImage: AssetImage(Assets.imgVector),
              ),
              12.pixelH,
              CommonText(
                "Payment Successfully",
                color: AppColors.primary,
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
              5.pixelH,
              CommonText(widget.item.title, color: Colors.grey),
              30.pixelH,

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  CommonText(
                    "Transaction details",
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                  Icon(Icons.keyboard_arrow_up),
                ],
              ),
              15.pixelH,

              Column(
                children: [
                  _row("Payment method", paymentMethod?.title ?? ''),
                  _row("Status", "Completed", Colors.green),

                  _row("Time", widget.item.paymentTime.toString()),

                  _row("Date", widget.item.paymentDate.toString()),
                  _row("Transaction ID", widget.item.transactionId.toString()),
                ],
              ),
              5.pixelH,
              const Divider(),
              5.pixelH,
              _row("Price", widget.item.price.toString()),
              _row("Fee", widget.item.fee.toString()),
              5.pixelH,
              Divider(),
              5.pixelH,

              _row("Total", widget.item.total.toString()),
              30.pixelH,

              SizedBox(
                width: double.infinity,
                height: 55,

                child: OutlinedButton(
                  style: OutlinedButton.styleFrom(
                    side: BorderSide(
                      color: AppColors.primary, // The color you want
                      width: 1, // Optional: thickness of the border
                    ),
                  ),
                  onPressed: () {},

                  child: const Text(
                    "Share Receipt",
                    style: TextStyle(color: AppColors.secondary),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

Widget _row(String title, String value, [Color? color]) {
  return Padding(
    padding: const EdgeInsets.symmetric(vertical: 4),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        CommonText(title, fontSize: 14),

        Text(
          value,
          style: TextStyle(color: color, fontWeight: FontWeight.w600),
        ),
      ],
    ),
  );
}
