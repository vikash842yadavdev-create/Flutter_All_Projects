import 'package:espenso/features/modules/wallet_module/data/models/wallet_item_model.dart';
import 'package:espenso/features/modules/wallet_module/presentation/controller/wallet_controller.dart';
import 'package:get/get.dart';

class TransactionDetailsController extends GetxController {
  late WalletItemModel transaction;

  @override
  void onInit() {
    super.onInit();
    transaction = Get.find<WalletController>().selectedTransaction.value!;
  }
}
