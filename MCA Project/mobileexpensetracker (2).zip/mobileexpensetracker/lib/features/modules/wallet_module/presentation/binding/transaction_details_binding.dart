import 'package:espenso/features/modules/wallet_module/presentation/controller/transaction_details_controller.dart';
import 'package:get/get.dart';

class TransactionDetailsBinding extends Bindings {
  @override
  void dependencies() {
    // TODO: implement dependencies
    Get.lazyPut<TransactionDetailsController>(
      () => TransactionDetailsController(),
    );
  }
}
