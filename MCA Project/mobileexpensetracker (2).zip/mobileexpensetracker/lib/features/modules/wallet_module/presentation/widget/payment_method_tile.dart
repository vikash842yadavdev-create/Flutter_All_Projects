import 'package:espenso/features/modules/wallet_module/data/models/payment_method_model.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../controller/payment_controller.dart';

class PaymentMethodTile extends GetView<PaymentController> {
  final PaymentMethodModel method;
  final int index;

  const PaymentMethodTile({
    super.key,
    required this.method,
    required this.index,
  });

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      final isSelected = controller.selectedIndex.value == index;

      return InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () => controller.selectMethod(index),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 250),
          margin: const EdgeInsets.only(bottom: 12),
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
          decoration: BoxDecoration(
            color: isSelected
                ? const Color(0xffEEF5F4)
                : const Color(0xffF8F8F8),
            borderRadius: BorderRadius.circular(18),
          ),
          child: Row(
            children: [
              Container(
                height: 40,
                width: 40,
                decoration: const BoxDecoration(
                  color: Colors.white,
                  shape: BoxShape.circle,
                ),
                child: Icon(method.icon, size: 24, color: Colors.grey),
              ),

              const SizedBox(width: 16),

              Expanded(
                child: Text(
                  method.title,
                  style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w600,
                    color: isSelected ? const Color(0xff4E9F8E) : Colors.grey,
                  ),
                ),
              ),

              AnimatedContainer(
                duration: const Duration(milliseconds: 250),
                height: 22,
                width: 22,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: isSelected ? const Color(0xff4E9F8E) : Colors.grey,
                    width: 2,
                  ),
                ),
                child: isSelected
                    ? Center(
                        child: Container(
                          height: 10,
                          width: 10,
                          decoration: const BoxDecoration(
                            shape: BoxShape.circle,
                            color: Color(0xff4E9F8E),
                          ),
                        ),
                      )
                    : null,
              ),
            ],
          ),
        ),
      );
    });
  }
}
