import 'package:espenso/features/modules/wallet_module/data/models/bill_model.dart';
import 'package:espenso/features/modules/wallet_module/presentation/controller/wallet_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class BillItemTile extends StatelessWidget {
  final BillModel bill;

  const BillItemTile({super.key, required this.bill});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
          // Get.find<WalletController>().openBill(bill);
          final controller = Get.find<WalletController>();

        controller.selectedBill.value = bill;
        controller.currentView.value = WalletAllView.billDetailView;
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 16),
        child: Row(
          children: [
            Container(
              width: 55,
              height: 55,
              decoration: BoxDecoration(
                color: const Color(0xffEDF4F3),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Padding(
                padding: const EdgeInsets.all(8),
                child: Image.asset(bill.image, fit: BoxFit.contain),
              ),
            ),

            const SizedBox(width: 12),

            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    bill.title,
                    style: const TextStyle(
                      fontWeight: FontWeight.w600,
                      fontSize: 14,
                    ),
                  ),

                  Text(
                    bill.dueDate,
                    style: TextStyle(color: Colors.grey.shade600,fontSize: 12),
                  ),
                ],
              ),
            ),

            Container(
              width: 90,
              height: 35,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: const Color(0xffEAF8F7),
                borderRadius: BorderRadius.circular(25),
              ),
              child: const Text(
                "Pay",
                style: TextStyle(
                  color: Color(0xff4F908A),
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
