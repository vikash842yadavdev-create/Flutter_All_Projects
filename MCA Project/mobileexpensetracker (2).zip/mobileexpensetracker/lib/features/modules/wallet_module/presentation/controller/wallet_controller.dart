import 'package:espenso/features/config/assets.dart';
import 'package:espenso/features/modules/wallet_module/data/models/bill_model.dart';
import 'package:espenso/features/modules/wallet_module/data/models/payment_method_model.dart';
import 'package:espenso/features/modules/wallet_module/data/models/wallet_item_model.dart';
import 'package:get/get.dart';


enum WalletAllView {
  walletHomeView,
  transactionDetailView,
  billDetailView,
  billPaymentView,
  paymentSuccessView,
}

class WalletController extends GetxController {
  static const int transactionsTab = 0;
  static const int billsTab = 1;

  RxInt selectedTab = transactionsTab.obs;

  void changeTab(int index) {
    selectedTab.value = index;
  }

  Rx<WalletAllView> currentView = WalletAllView.walletHomeView.obs;

  Rx<WalletItemModel?> selectedTransaction = Rx<WalletItemModel?>(null);

  Rx<BillModel?> selectedBill = Rx<BillModel?>(null);

  Rx<PaymentMethodModel?> selectedPaymentMethod = Rx<PaymentMethodModel?>(null);

  void openTransaction(WalletItemModel transaction) {
    selectedTransaction.value = transaction;

    currentView.value = WalletAllView.transactionDetailView;
  }

  void openBill(BillModel bill) {
    selectedBill.value = bill;
    currentView.value = WalletAllView.billDetailView;
  }

  void openBillDetail(WalletItemModel bill) {
    selectedTransaction.value = bill;
    currentView.value = WalletAllView.billDetailView;
  }

  void openBillPayment() {
    currentView.value = WalletAllView.billPaymentView;
  }

  void openPaymentSuccess() {
    currentView.value = WalletAllView.paymentSuccessView;
  }

  void backToBillDetail() {
    currentView.value = WalletAllView.billDetailView;
  }

  void backToWallet() {
    currentView.value = WalletAllView.walletHomeView;
  }

  final transactions = <WalletItemModel>[
    WalletItemModel(
      title: "Upwork",
      subtitle: "Today",
      image: Assets.imgTUpwork,
      amount: "\$850.00",
      isIncome: true,
      status: "Income",
      personName: "Upwork Escrow",
      time: "10:00 AM",
      date: "Feb 30, 2022",
      fee: "\$20.00",
    ),

    WalletItemModel(
      title: "Transfer",
      subtitle: "Yesterday",
      image: Assets.imgTPerson,
      amount: "\$85.00",
      isIncome: false,
      status: "Expense",
      personName: "Claire Jovalski",
      time: "04:30 PM",
      date: "Feb 29, 2022",
      fee: "\$0.99",
    ),

    WalletItemModel(
      title: "Paypal",
      subtitle: "Jan 30, 2022",
      image: Assets.imgTPaypal,
      amount: "\$1,406.00",
      isIncome: true,
      status: "Income",
      personName: "Paypal Inc.",
      time: "01:20 PM",
      date: "Jan 30, 2022",
      fee: "\$15.00",
    ),

    WalletItemModel(
      title: "Youtube",
      subtitle: "Jan 16, 2022",
      image: Assets.imgTYoutube,
      amount: "\$11.99",
      isIncome: false,
      status: "Expense",
      personName: "Youtube Premium",
      time: "11:15 AM",
      date: "Jan 16, 2022",
      fee: "\$0.50",
    ),
  ].obs;

  final upcomingBills = <BillModel>[
    BillModel(
      id: "1",
      title: "Youtube Premium",
      image: Assets.imgTYoutube,
      dueDate: "Feb 28, 2022",

      price: 11.99,
      fee: 1.99,
      total: 13.98,

      paymentMethod: "Debit Card",

      status: "Pending",

      transactionId: "",
      paymentTime: "",
      paymentDate: "",
    ),

    BillModel(
      id: "2",
      title: "Electricity",
      image: "assets/icons/electricity.png",
      dueDate: "Mar 28, 2022",

      price: 120.00,
      fee: 2.00,
      total: 122.00,

      paymentMethod: "Debit Card",

      status: "Pending",

      transactionId: "",
      paymentTime: "",
      paymentDate: "",
    ),

    BillModel(
      id: "3",
      title: "House Rent",
      image: "assets/icons/home.png",
      dueDate: "Mar 31, 2022",

      price: 650.00,
      fee: 5.00,
      total: 655.00,

      paymentMethod: "Debit Card",

      status: "Pending",

      transactionId: "",
      paymentTime: "",
      paymentDate: "",
    ),

    BillModel(
      id: "4",
      title: "Spotify Premium",
      image: "assets/icons/spotify.png",
      dueDate: "Feb 28, 2022",

      price: 9.99,
      fee: 1.00,
      total: 10.99,

      paymentMethod: "Paypal",

      status: "Pending",

      transactionId: "",
      paymentTime: "",
      paymentDate: "",
    ),
  ].obs;
}
