import 'package:espenso/features/config/helper.dart';
import 'package:espenso/features/modules/common_widgets/common_text_widget.dart';
import 'package:flutter/material.dart';
class ActionItemWidget extends StatelessWidget {
  final IconData icon;
  final String title;
  final VoidCallback? onTap;
  final double size;
  final double? iconSize;

  const ActionItemWidget({
    super.key,
    required this.icon,
    required this.title,
    this.onTap,
    this.size = 60,
    this.iconSize,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(50),
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            height: size,
            width: size,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(50),
              border: Border.all(color: AppColors.primary),
            ),
            child: Icon(icon, color: AppColors.secondary, size: iconSize),
          ),

          5.pixelH,

          CommonText(title, fontSize: 14),
        ],
      ),
    );
  }
}
