import 'package:espenso/features/config/assets.dart';
import 'package:espenso/features/config/helper.dart';
import 'package:espenso/features/modules/common_widgets/common_button.dart';
import 'package:espenso/features/modules/common_widgets/common_small_widgets/custom_headerbar_widget.dart';
import 'package:espenso/features/modules/common_widgets/common_text_widget.dart';
import 'package:espenso/features/modules/wallet_module/data/models/bill_model.dart';
import 'package:espenso/features/modules/wallet_module/data/models/payment_method_model.dart';
import 'package:espenso/features/modules/wallet_module/presentation/controller/payment_controller.dart';
import 'package:espenso/features/modules/wallet_module/presentation/controller/wallet_controller.dart';
import 'package:espenso/features/modules/wallet_module/presentation/widget/payment_method_tile.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';


class BillDetailView extends StatefulWidget {
  final BillModel item;

  const BillDetailView({super.key, required this.item});

  @override
  State<BillDetailView> createState() => _BillDetailViewState();
}

class _BillDetailViewState extends State<BillDetailView> {
  @override
  Widget build(BuildContext context) {
    final PaymentController controller = Get.put(PaymentController());

    final methods = [
      PaymentMethodModel(title: "Debit Card", icon: Icons.credit_card),
      PaymentMethodModel(title: "Paypal", icon: Icons.paypal),
    ];

    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage(Assets.imgBackground2),
            fit: BoxFit.cover,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            children: [
              40.pixelH,
              CustomHeaderBar(
                onLeadingTap: () {
                  Get.find<WalletController>().currentView.value =
                      WalletAllView.walletHomeView;
                },
                title: "Bill Details",
                actionIcon: Icons.more_horiz,
              ),
              50.pixelH,

              Row(
                children: [
                  CircleAvatar(
                    radius: 40,
                    child: Image(image: AssetImage(widget.item.image)),
                  ),
                  15.pixelW,
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      CommonText(
                        widget.item.title,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                      CommonText(widget.item.dueDate),
                    ],
                  ),
                ],
              ),
              40.pixelH,

              _row("Price", widget.item.price.toString()),
              _row("Fee", widget.item.fee.toString()),
              5.pixelH,
              Divider(),
              5.pixelH,

              _row("Total", widget.item.total.toString()),
              30.pixelH,
              Align(
                alignment: AlignmentGeometry.centerStart,
                child: CommonText(
                  "Select payment method",
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              20.pixelH,
              Column(
                children: List.generate(
                  methods.length,
                  (index) =>
                      PaymentMethodTile(method: methods[index], index: index),
                ),
              ),
              30.pixelH,

              CommonButton(
                text: "Pay Now",
                ontap: () {
                  final paymentController = Get.find<PaymentController>();

                  final selectedMethod =
                      methods[paymentController.selectedIndex.value];

                  final walletController = Get.find<WalletController>();

                  walletController.selectedPaymentMethod.value = selectedMethod;

                  walletController.currentView.value =
                      WalletAllView.billPaymentView;
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

Widget _row(String title, String value, [Color? color]) {
  return Padding(
    padding: const EdgeInsets.symmetric(vertical: 4),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        CommonText(title, fontSize: 14),

        Text(
          value,
          style: TextStyle(color: color, fontWeight: FontWeight.w600),
        ),
      ],
    ),
  );
}
