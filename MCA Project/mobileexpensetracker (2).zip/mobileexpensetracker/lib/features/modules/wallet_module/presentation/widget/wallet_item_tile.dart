import 'package:espenso/features/modules/wallet_module/data/models/wallet_item_model.dart';
import 'package:espenso/features/modules/wallet_module/presentation/controller/wallet_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class WalletItemTile extends StatelessWidget {
  final WalletItemModel item;
  final bool isBill;

  const WalletItemTile({super.key, required this.item, this.isBill = false});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        final controller = Get.find<WalletController>();

        controller.selectedTransaction.value = item;

        if (isBill) {
          controller.currentView.value = WalletAllView.billDetailView;
        } else {
          controller.currentView.value = WalletAllView.transactionDetailView;
        }
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 16),
        child: Row(
          children: [
            Container(
              width: 55,
              height: 55,
              decoration: BoxDecoration(
                color: const Color(0xffEDF4F3),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Padding(
                padding: const EdgeInsets.all(3),
                child: Image.asset(item.image),
              ),
            ),

            const SizedBox(width: 12),

            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    item.title,
                    style: const TextStyle(
                      fontWeight: FontWeight.w600,
                      fontSize: 18,
                    ),
                  ),
                  Text(
                    item.subtitle,
                    style: TextStyle(color: Colors.grey.shade600),
                  ),
                ],
              ),
            ),

            isBill
                ? Container(
                    width: 110,
                    height: 45,
                    decoration: BoxDecoration(
                      color: const Color(0xffEAF8F7),
                      borderRadius: BorderRadius.circular(25),
                    ),
                    alignment: Alignment.center,
                    child: const Text(
                      "Pay",
                      style: TextStyle(
                        color: Color(0xff4F908A),
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  )
                : Text(
                    "${item.isIncome ? '+' : '-'} ${item.amount}",
                    style: TextStyle(
                      color: item.isIncome ? Colors.green : Colors.red,
                      fontWeight: FontWeight.bold,
                      fontSize: 20,
                    ),
                  ),
          ],
        ),
      ),
    );
  }
}
