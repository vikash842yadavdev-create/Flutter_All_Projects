import 'package:get/get.dart';
import 'package:espenso/features/modules/onboarding_module/presentation/controler/onboarding_controler.dart';

class OnboardingBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<OnboardingController>(() => OnboardingController());
  }
}
