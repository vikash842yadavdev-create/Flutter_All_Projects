import 'package:espenso/features/config/helper.dart';
import 'package:espenso/features/modules/onboarding_module/presentation/controler/splash_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class SplashView extends StatelessWidget {
  const SplashView({super.key});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<SplashController>(
      builder: (controller) {
        return Scaffold(
          body: Container(
            color: AppColors.primary,
            child: Center(
              child: ScaleTransition(
                scale: controller.scaleAnimation,
                child: FadeTransition(
                  opacity: controller.fadeAnimation,
                  child: Text(
                    'Expenso',
                    style: TextStyle(
                      fontSize: 50,
                      fontWeight: FontWeight.bold,
                      color: AppColors.white,
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
