import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:espenso/features/config/assets.dart';
import 'package:espenso/features/config/helper.dart';
import 'package:espenso/features/config/routes/app_pages.dart';
import 'package:espenso/features/modules/common_widgets/common_button.dart';
import 'package:espenso/features/modules/common_widgets/common_image_widget.dart';

class OnboardingView extends StatefulWidget {
  const OnboardingView({super.key});

  @override
  State<OnboardingView> createState() => _OnboardingViewState();
}

class _OnboardingViewState extends State<OnboardingView> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage(Assets.imgOnboardingBackground),
            fit: BoxFit.cover,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 28),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              CommonImageWidget(
                img: Assets.imgOnboardingMan,
                height: 400,
                width: double.infinity,
                fit: BoxFit.contain,
              ),
              10.pixelH,
              Text(
                "Spend Smarter \n Save More",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 36,
                  fontWeight: FontWeight.bold,
                  color: AppColors.secondary,
                  height: 1,
                ),
              ),
              26.pixelH,

              CommonButton(
                text: "Get Started",
                isGradient: true,
                isShadow: true,
                ontap: (

                ) {
                  // Navigate to the next screen
                  Get.toNamed(Routes.signUpView);
                },
              ),
              20.pixelH,

              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "Already have account?",
                    style: TextStyle(fontSize: 14, color: AppColors.black),
                  ),
                  5.pixelW,
                  InkWell(
                    onTap: () {
                      // Navigate to the login screen
                      Get.toNamed(Routes.loginView);
                    },
                    child: Text(
                      "Log In",
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        color: AppColors.secondary,
                        height: 1,
                      ),
                    ),
                  ),
                ],
              ),
              40.pixelH,
            ],
          ),
        ),
      ),
    );
  }
}
