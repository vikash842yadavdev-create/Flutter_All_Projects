import 'package:espenso/features/config/assets.dart';
import 'package:espenso/features/config/helper.dart';
import 'package:espenso/features/config/routes/app_pages.dart';
import 'package:espenso/features/modules/common_widgets/common_button.dart';
import 'package:espenso/features/modules/common_widgets/common_image_widget.dart';
import 'package:espenso/features/modules/common_widgets/common_text_field.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class LoginView extends StatefulWidget {
  const LoginView({super.key});

  @override
  State<LoginView> createState() => _LoginViewState();
}

class _LoginViewState extends State<LoginView> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      body: SingleChildScrollView(
        child: Container(
          width: double.infinity,
          constraints: BoxConstraints(
            minHeight: MediaQuery.of(context).size.height,
          ),
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage(Assets.imgBackground),
              fit: BoxFit.cover,
            ),
          ),
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  70.pixelH,

                  CommonImageWidget(
                    img: Assets.imgProfileDummy,
                    height: 120,
                    width: double.infinity,
                    fit: BoxFit.contain,
                  ),

                  20.pixelH,

                  Text(
                    'Welcome',
                    style: TextStyle(
                      fontSize: 36,
                      fontWeight: FontWeight.bold,
                      color: AppColors.secondary,
                    ),
                  ),

                  20.pixelH,

                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      'Email',
                      style: TextStyle(fontSize: 14, color: AppColors.black),
                    ),
                  ),

                  5.pixelH,

                  CommonTextField(
                    verticalPadding: 0,
                    hintText: 'example@gmail.com',
                    hintTextSize: 12,
                    hintTextColor: AppColors.textfield_primary,
                    borderRadius: 8,
                  ),

                  10.pixelH,

                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      'Password',
                      style: TextStyle(fontSize: 14, color: AppColors.black),
                    ),
                  ),

                  5.pixelH,

                  CommonTextField(
                    verticalPadding: 0,
                    hintText: '********',
                    hintTextSize: 12,
                    hintTextColor: AppColors.textfield_primary,
                    borderRadius: 8,
                  ),

                  20.pixelH,

                  CommonButton(
                    text: 'Log In',
                    textSize: 16,
                    isGradient: true,
                    isShadow: true,
                    ontap: () {
                      Get.offNamed(Routes.mainView);
                    },
                  ),

                  20.pixelH,

                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        "Don't have an account?",
                        style: TextStyle(fontSize: 14, color: AppColors.black),
                      ),

                      5.pixelW,

                      InkWell(
                        onTap: () {
                          Get.toNamed(Routes.signUpView);
                        },
                        child: Text(
                          "Sign Up",
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            color: AppColors.secondary,
                          ),
                        ),
                      ),
                    ],
                  ),

                  40.pixelH,
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
