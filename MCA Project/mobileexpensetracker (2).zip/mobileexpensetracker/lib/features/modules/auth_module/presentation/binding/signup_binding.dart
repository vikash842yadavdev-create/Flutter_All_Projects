import 'package:get/get.dart';
import 'package:espenso/features/modules/auth_module/presentation/controler/signup_controller.dart';

class SignUpBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<SignUpController>(() => SignUpController());
  }
}
