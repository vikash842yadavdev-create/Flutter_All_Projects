import 'package:flutter/material.dart';
import 'package:espenso/features/config/helper.dart';

class CommonButton extends StatelessWidget {
  final String text;
  final Color color;
  final Color textColor;
  final VoidCallback ontap;
  final Widget? prefix;
  final Widget? suffix;
  final bool? isShadow;
  final bool? isGradient;
  final double? textSize;
  const CommonButton({
    super.key,
    required this.text,
    this.color = AppColors.primary,
    this.textColor = AppColors.white,
    required this.ontap,
    this.prefix,
    this.suffix,
    this.isShadow = false,
    this.isGradient = false,
    this.textSize = 16,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(100),
      onTap: ontap,
      child: Container(
        height: 50,
        width: context.width,
        padding: EdgeInsets.symmetric(horizontal: 18, vertical: 12),
        decoration: BoxDecoration(
          gradient: isGradient == true ? AppColors.linearGradient : null,
          color: isGradient == false ? color : null,
          borderRadius: 100.borderRadius,
          boxShadow: isShadow == true
              ? [
                  BoxShadow(
                    color: color.withValues(alpha: 0.5),
                    spreadRadius: 6,
                    blurRadius: 12,
                    offset: Offset(0, 8), // changes position of shadow
                  ),
                ]
              : null,
        ),
        child: Center(
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              prefix != null ? prefix! : const SizedBox(),
              if (prefix != null) 8.pixelW,
              Text(
                text,
                style: context.appTextTheme.bodyLarge?.copyWith(
                  color: textColor,
                  fontWeight: FontWeight.w600,
                  fontSize: textSize,
                ),
              ),
              if (suffix != null) 8.pixelW,
              if (suffix != null) suffix!,
            ],
          ),
        ),
      ),
    );
  }
}
