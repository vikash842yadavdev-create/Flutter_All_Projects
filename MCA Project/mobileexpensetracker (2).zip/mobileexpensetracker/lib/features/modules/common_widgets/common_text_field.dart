import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:espenso/features/config/assets.dart';
import 'package:espenso/features/config/helper.dart';
import 'package:espenso/features/modules/common_widgets/common_image_widget.dart';

class CommonTextField extends StatefulWidget {
  final TextEditingController? controller;
  final bool? obscureText, isEnabled;
  final TextInputType? keyboardType;
  final Widget? prefixIcon;
  final Widget? suffixIcon;
  final String? hintText;
  final String? prefixText;
  final int? maxLines;
  final int? minLines;
  final double horizontalPadding, verticalPadding;
  final double? contantPaddingHorizontal, contantPaddingVertical;
  final int? maxLength;
  final Color? borderColor, bgColor;
  final Color? hintTextColor;
  final double? hintTextSize;
  final Color? suffixColor;
  final Color? suffixFocusedColor;
  final TextCapitalization? textCapitalization;
  final double? borderRadius;
  final FocusNode? focusNode;
  final TextInputAction? textInputAction;
  final ValueChanged<String>? onChanged;
  final List<TextInputFormatter>? inputFormatters;

  const CommonTextField({
    super.key,
    this.controller,
    this.obscureText,
    this.textCapitalization,
    this.focusNode,
    this.horizontalPadding = 0,
    this.verticalPadding = 2,
    this.contantPaddingHorizontal = 10,
    this.contantPaddingVertical = 10,
    this.onChanged,
    this.isEnabled,
    this.bgColor = AppColors.white,
    this.borderColor = AppColors.primary,
    this.inputFormatters,
    this.borderRadius,
    this.keyboardType,
    this.maxLength,
    this.prefixIcon,
    this.hintTextColor,
    this.suffixIcon,
    this.prefixText,
    this.hintText,
    this.hintTextSize,
    this.minLines,
    this.maxLines = 1,
    this.suffixColor = AppColors.black,
    this.suffixFocusedColor = AppColors.black,
    this.textInputAction,
  });

  // suffixFocusedColor: AppColor.primary,
  // suffixColor: AppColor.textFieldHintTextColor,

  @override
  State<CommonTextField> createState() => _CommonTextFieldState();
}

class _CommonTextFieldState extends State<CommonTextField> {
  late FocusNode _focusNode;

  @override
  void initState() {
    super.initState();
    _focusNode = FocusNode()
      ..addListener(() {
        setState(() {});
      });
  }

  @override
  void dispose() {
    _focusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isFocused = (widget.focusNode ?? _focusNode).hasFocus;

    final borderProperties = OutlineInputBorder(
      borderRadius: BorderRadius.circular(widget.borderRadius ?? 50),
      borderSide: BorderSide(color: widget.borderColor ?? AppColors.white),
    );

    Color? suffixIconColor = isFocused
        ? widget.suffixFocusedColor
        : widget.suffixColor;

    return Padding(
      padding: EdgeInsets.symmetric(
        horizontal: widget.horizontalPadding,
        vertical: widget.verticalPadding,
      ),
      child: TextField(
        focusNode: widget.focusNode ?? _focusNode,
        maxLines: widget.maxLines,
        minLines: widget.minLines,
        style: context.appTextTheme.displayMedium?.copyWith(
          fontWeight: FontWeight.w600,
          fontSize: 16,
          color: AppColors.black,
        ),
        cursorColor: AppColors.primary,
        obscureText: widget.obscureText ?? false,
        controller: widget.controller,
        textInputAction: widget.textInputAction,
        inputFormatters: widget.inputFormatters,
        textCapitalization:
            widget.textCapitalization ?? TextCapitalization.none,
        keyboardType: widget.keyboardType,
        onChanged: widget.onChanged,
        maxLength: widget.maxLength,
        decoration: InputDecoration(
          contentPadding: EdgeInsets.symmetric(
            horizontal: widget.contantPaddingHorizontal ?? 10,
            vertical: widget.contantPaddingVertical ?? 10,
          ),
          counterText: "",
          disabledBorder: OutlineInputBorder(
            borderSide: BorderSide(
              color: widget.borderColor ?? AppColors.white,
            ),
            borderRadius: BorderRadius.circular(widget.borderRadius ?? 50),
          ),
          enabled: widget.isEnabled ?? true,
          filled: true,
          fillColor: widget.bgColor ?? AppColors.white,
          prefixIcon: widget.prefixIcon,
          suffixIcon: widget.suffixIcon != null
              ? Padding(
                  padding: const EdgeInsets.only(left: 13.0, right: 10),
                  child: IconTheme(
                    data: IconThemeData(color: suffixIconColor),
                    child: widget.suffixIcon!,
                  ),
                )
              : null,
          prefixText: widget.prefixText,
          prefixStyle: context.appTextTheme.bodyMedium?.copyWith(
            color: AppColors.black,
          ),
          hintText: widget.hintText ?? "",
          hintStyle: context.appTextTheme.bodyMedium?.copyWith(
            fontSize: widget.hintTextSize ?? 16,
            fontWeight: FontWeight.w500,
            // fontFamily: AppConstants.montserrat,
            color: widget.hintTextColor ?? AppColors.black,
          ),
          errorBorder: borderProperties,
          enabledBorder: borderProperties,
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(widget.borderRadius ?? 50),
            borderSide: BorderSide(color: AppColors.black, width: 1.5),
          ),
          border: borderProperties,
        ),
      ),
    );
  }
}

class PasswordTextField extends StatefulWidget {
  final TextEditingController? controller;
  final bool? isEnabled;
  final TextInputAction? textInputAction;
  final String? hintText;
  final String? label;
  final double horizontalPadding;
  final double verticalPadding;
  final double? borderRadius;
  final Color? bgColor;
  final Color? cursorColor;
  final Color? suffixColor;
  final Color? suffixFocusedColor;
  final Color? borderColor;
  final Color? hintTextColor;
  final ValueChanged<String>? onChanged;
  final List<TextInputFormatter>? inputFormatters;
  final int? maxLines;
  final int? maxLength;
  final bool initialObscure;
  final void Function()? onTap;
  final bool? readOnly;
  final TextCapitalization? textCapitalization;

  const PasswordTextField({
    super.key,
    this.controller,
    this.isEnabled,
    this.textInputAction,
    this.hintText,
    this.label,
    this.horizontalPadding = 0,
    this.verticalPadding = 2,
    this.borderRadius,
    this.bgColor,
    this.cursorColor,
    this.suffixColor,
    this.suffixFocusedColor,
    this.borderColor,
    this.hintTextColor,
    this.onChanged,
    this.inputFormatters,
    this.maxLines = 1,
    this.maxLength,
    this.initialObscure = true,
    this.onTap,
    this.readOnly,
    this.textCapitalization,
  });

  @override
  State<PasswordTextField> createState() => _PasswordTextFieldState();
}

class _PasswordTextFieldState extends State<PasswordTextField> {
  late bool _obscure;
  late FocusNode _focusNode;

  @override
  void initState() {
    super.initState();
    _obscure = widget.initialObscure;
    _focusNode = FocusNode()..addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    _focusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isFocused = _focusNode.hasFocus;

    final borderProperties = OutlineInputBorder(
      borderRadius: BorderRadius.circular(widget.borderRadius ?? 50),
      borderSide: BorderSide(
        color: isFocused ? AppColors.black : AppColors.red,
        width: isFocused ? 1.2 : 1,
      ),
      // borderSide: BorderSide(
      //   color: borderSideColor,
      //   width: isFocused ? 1.2 : 1.02,
      // ),
    );

    return GestureDetector(
      onTap: () {
        // if the field is disabled but onTap provided, call it
        if (widget.isEnabled == false) {
          widget.onTap?.call();
        }
      },
      child: Padding(
        padding: EdgeInsets.symmetric(
          horizontal: widget.horizontalPadding,
          vertical: widget.verticalPadding,
        ),
        child: TextField(
          controller: widget.controller,
          readOnly: widget.readOnly ?? false,
          enabled: widget.isEnabled ?? true,
          focusNode: _focusNode,
          obscureText: _obscure,
          obscuringCharacter: "•",
          textAlignVertical: TextAlignVertical.center,
          maxLines: widget.maxLines,
          inputFormatters: widget.inputFormatters,
          textInputAction: widget.textInputAction,
          textCapitalization:
              widget.textCapitalization ?? TextCapitalization.none,
          onChanged: widget.onChanged,
          maxLength: widget.maxLength,
          cursorColor: widget.cursorColor ?? Theme.of(context).primaryColor,
          style: context.appTextTheme.displayMedium?.copyWith(
            fontWeight: FontWeight.w600,
            fontSize: 16,
            color: AppColors.black,
          ),
          decoration: InputDecoration(
            // isDense: true,
            // contentPadding: const EdgeInsets.symmetric(
            //   horizontal: 25,
            //   vertical: 15,
            // ),
            counterText: "",
            filled: true,
            fillColor: widget.bgColor ?? AppColors.white,
            enabledBorder: borderProperties,
            focusedBorder: borderProperties,
            errorBorder: borderProperties,
            disabledBorder: borderProperties,
            border: borderProperties,
            prefixText: null,
            hintText: widget.hintText ?? "",
            hintStyle: context.appTextTheme.bodyMedium?.copyWith(
              fontSize: 16,
              fontWeight: FontWeight.w500,
              // fontFamily: AppConstants.montserrat,
              color: widget.hintTextColor ?? AppColors.black,
            ),
            suffixIcon: InkWell(
              splashFactory: NoSplash.splashFactory,
              onTap: () {
                setState(() {
                  _obscure = !_obscure;
                });
              },
              child: Container(
                alignment: Alignment.centerRight,
                width: 26,
                child: Padding(
                  padding: const EdgeInsets.all(
                    12,
                  ).copyWith(right: 20, left: 0),
                  child: CommonImageWidget(
                    img: _obscure ? Assets.icBackArrow : Assets.icBackArrow,
                    height: _obscure ? 20 : 18,
                    width: _obscure ? 18 : 18,
                  ),
                ),
              ),
            ),

            // IconButton(
            //   padding: const EdgeInsets.only(right: 12),
            //   onPressed: () {
            //     setState(() {
            //       _obscure = !_obscure;
            //     });
            //   },
            //   icon: Icon(
            //     _obscure ? Icons.visibility_off : Icons.visibility,
            //     // color handled by IconTheme below
            //   ),
            // ),
            labelText: widget.label,
          ),
          onTap: widget.onTap,
        ),
      ),
    );
  }
}
