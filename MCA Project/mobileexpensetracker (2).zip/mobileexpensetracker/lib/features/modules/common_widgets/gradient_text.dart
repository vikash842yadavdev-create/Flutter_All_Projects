import 'package:flutter/material.dart';
import 'package:espenso/features/config/app_constants.dart';
import 'package:espenso/features/config/helper.dart';

class GradientText extends StatelessWidget {
  final String text;
  final TextStyle? style;
  final double? fontSize;
  final Gradient gradient;
  final bool verticalGradient; // New parameter for gradient direction

  const GradientText(
    this.text, {
    super.key,
    this.fontSize,
    this.gradient = AppColors.linearGradient,
    this.style,
    this.verticalGradient = false, // Default to horizontal
  });

  @override
  Widget build(BuildContext context) {
    // Create base style with defaults if none provided
    final baseStyle =
        style ??
        const TextStyle(
          fontSize: 24,
          fontWeight: FontWeight.bold,
          fontFamily: AppConstants.oxanium,
        );

    // Apply fontSize if provided
    final textStyle = fontSize != null
        ? baseStyle.copyWith(fontSize: fontSize)
        : baseStyle;

    // Calculate text dimensions
    final textPainter = TextPainter(
      text: TextSpan(text: text, style: textStyle),
      textDirection: TextDirection.ltr,
      maxLines: 1,
    )..layout();

    return Text(
      text,
      style: textStyle.copyWith(
        foreground: Paint()
          ..shader = gradient.createShader(
            verticalGradient
                ? Rect.fromLTWH(0, 0, textPainter.width, textPainter.height)
                : Rect.fromLTWH(
                    0,
                    0,
                    textPainter.width * 1.2, // Extra width for horizontal
                    textStyle.fontSize! * 1.2,
                  ),
          ),
      ),
    );
  }
}
