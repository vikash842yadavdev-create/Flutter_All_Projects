import 'package:espenso/features/config/helper.dart';
import 'package:flutter/material.dart';

class CustomHeaderBar extends StatelessWidget {
  final String title;
  final IconData leadingIcon;
  final IconData? actionIcon;

  final VoidCallback? onLeadingTap;
  final VoidCallback? onActionTap;

  final Color backgroundColor;
  final Color iconColor;
  final Color titleColor;

  const CustomHeaderBar({
    Key? key,
    required this.title,
    this.leadingIcon = Icons.arrow_back_ios,
    this.actionIcon,
    this.onLeadingTap,
    this.onActionTap,
    this.backgroundColor = AppColors.transparent,
    this.iconColor = Colors.white,
    this.titleColor = Colors.white,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 50,
      color: backgroundColor,
      child: Row(
        children: [
          GestureDetector(
            onTap: onLeadingTap,
            child: Icon(leadingIcon, color: iconColor,size: 20,),
          ),

          Expanded(
            child: Center(
              child: Text(
                title,
                style: TextStyle(
                  color: titleColor,
                  fontSize: 20,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ),

          actionIcon != null
              ? GestureDetector(
                  onTap: onActionTap,
                  child: Icon(actionIcon, color: iconColor),
                )
              : const SizedBox(width: 24),
        ],
      ),
    );
  }
}
