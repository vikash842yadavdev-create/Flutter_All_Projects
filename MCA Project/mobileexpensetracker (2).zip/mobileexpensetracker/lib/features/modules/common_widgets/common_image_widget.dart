import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:espenso/features/config/helper.dart';

class CommonImageWidget extends StatelessWidget {
  final String img;
  final double? height;
  final double? width;
  final Color? borderColor, svgColorFilter;
  final double? imageRadius;
  final bool? isLocalFile;
  final Widget? errorWidget;
  final BoxFit? fit;
  final double? borderWidth;

  const CommonImageWidget({
    super.key,
    required this.img,
    this.height = 90,
    this.width = 90,
    this.errorWidget,
    this.isLocalFile = false,
    this.fit,
    this.borderColor,
    this.svgColorFilter,
    this.imageRadius,
    this.borderWidth,
  });

  /// Counts the occurrences of 'https' in the given URL.
  int countHttpsOccurrences(String url) {
    return RegExp('https').allMatches(url).length;
  }

  /// Extracts the last word before the file extension from the URL.
  String extractLastWord(String url) {
    String lastPart = url.split('/').last;
    return lastPart.split('.').first;
  }

  /// Builds a fallback widget for invalid images.
  Widget _buildFallbackImage() {
    return errorWidget ??
        SizedBox(
          height: height,
          width: width,
          child: CircleAvatar(
            radius: imageRadius,
            backgroundColor: AppColors.transparent,
          ),
        );
  }

  @override
  Widget build(BuildContext context) {
    if (isLocalFile ?? false) {
      return ClipRRect(
        borderRadius: (imageRadius ?? 10).circularBorder,
        child: SizedBox(
          height: height,
          width: width,
          child: Image.file(
            File(img),
            frameBuilder: (context, child, frame, wasSynchronouslyLoaded) {
              if (frame != null) {
                return child;
              }
              return const Center(child: Text("Loading..."));
            },
            height: height,
            width: width,
            fit: fit,
          ),
        ),
      );
    }

    if (img.contains(".svg") && img.contains("https")) {
      return SvgPicture.network(
        img,
        height: height,
        width: width,

        colorFilter: svgColorFilter != null
            ? ColorFilter.mode(
          svgColorFilter ?? AppColors.black,
          BlendMode.srcIn,
        )
            : null,
      );
    }

    if (img.contains(".svg") && img.contains("assets/")) {
      return SvgPicture.asset(
        img,
        height: height,
        width: width,

        colorFilter: svgColorFilter != null
            ? ColorFilter.mode(
          svgColorFilter ?? AppColors.black,
          BlendMode.srcIn,
        )
            : null,
      );
    }

    // Case 1: Local asset image
    if (img.contains("assets/") && (!img.isURL)) {
      return SizedBox(
        height: height,
        width: width,
        child: Image.asset(img, fit: fit),
        // CircleAvatar(
        //   radius: imageRadius,
        //   backgroundColor: AppColors.transparent,
        //   backgroundImage: AssetImage(img),
        // ),
      );
    }

    // Case 2: Invalid URLs with multiple 'https' or missing meaningful content
    if (countHttpsOccurrences(img) > 1 ||
        extractLastWord(img).isEmpty ||
        extractLastWord(img) == "null") {
      return _buildFallbackImage();
    }

    // Case 3: Empty or placeholder values for the image URL
    if (img.isEmpty || img == '-' || img == '') {
      return _buildFallbackImage();
    }

    // Case 4: SVG or cached network images
    return Container(
      width: width,
      height: height,
      alignment: Alignment.center,
      child: Image.network(
        img,
        fit: fit,
        frameBuilder: (context, child, frame, wasSynchronouslyLoaded) {
          return ClipRRect(
            borderRadius: BorderRadius.all(Radius.circular(imageRadius ?? 0)),
            child: Container(
              height: height,
              width: width,
              decoration: BoxDecoration(
                borderRadius: imageRadius != null
                    ? BorderRadius.circular(imageRadius!)
                    : null,

                border: Border.all(
                  color: borderColor ?? AppColors.transparent,
                  width: borderWidth ?? 0,
                ),
              ),
              child: child,
            ),
          );
        },
        loadingBuilder: (context, child, loadingProgress) {
          if (loadingProgress == null) return child;
          // final totalBytes = loadingProgress.expectedTotalBytes;
          // final loadedBytes = loadingProgress.cumulativeBytesLoaded;

          // double? progress = totalBytes != null
          //     ? loadedBytes / totalBytes
          //     : null;

          return TiltedShimmer(
            child: Container(
              height: height,
              width: width,
              decoration: BoxDecoration(
                color: AppColors.white,
                borderRadius: imageRadius != null
                    ? BorderRadius.circular(imageRadius!)
                    : null,
                border: Border.all(
                  color: borderColor ?? AppColors.transparent,
                  width: borderWidth ?? 0,
                ),
              ),
              child: const Center(),
            ),
          );
        },
        errorBuilder: (context, error, stackTrace) {
          return ClipRRect(
            borderRadius: BorderRadius.circular(imageRadius ?? 10),
            child: errorWidget ?? SizedBox(height: height, width: width),
          );
        },
      ),
    );
  }
}

class TiltedShimmer extends StatefulWidget {
  final Widget child;
  const TiltedShimmer({required this.child, super.key});

  @override
  State<TiltedShimmer> createState() => _TiltedShimmerState();
}

class _TiltedShimmerState extends State<TiltedShimmer>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (_, __) {
        return ShaderMask(
          blendMode: BlendMode.srcATop,
          shaderCallback: (bounds) {
            final width = bounds.width;
            final height = bounds.height;
            final offset = _controller.value * (width + height);

            return LinearGradient(
              begin: const Alignment(-1.0, -1.0),
              end: const Alignment(1.0, 1.0),
              colors: [
                Colors.grey.shade400,
                Colors.grey.shade100,
                Colors.grey.shade400,
              ],
              stops: const [0.3, 0.5, 0.7],
              transform: const GradientRotation(math.pi / 1), // 45-degree tilt
            ).createShader(
              Rect.fromLTWH(-offset, -offset, width + height, width + height),
            );
          },
          child: widget.child,
        );
      },
    );
  }
}

class NamedErrorWidget extends StatelessWidget {
  final String? name;
  final double? size;
  const NamedErrorWidget({required this.name, super.key, this.size});

  @override
  Widget build(BuildContext context) {
    return Text(
      getFirstLetter(name).toUpperCase(),
      style: context.appTextTheme.headlineMedium?.copyWith(
        fontSize: size ?? 18,
      ),
    );
  }

  String getFirstLetter(String? name) {
    try {
      return name![0];
    } catch (e) {
      return "U";
    }
  }
}

