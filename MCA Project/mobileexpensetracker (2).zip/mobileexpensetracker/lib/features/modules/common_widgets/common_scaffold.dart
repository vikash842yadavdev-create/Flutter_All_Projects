import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:espenso/features/config/assets.dart';
import 'package:espenso/features/config/helper.dart';


class CommonScaffold extends StatelessWidget {
  final Widget? body;
  final Widget? floatingActionButton;
  final FloatingActionButtonLocation? floatingActionButtonLocation;
  final FloatingActionButtonAnimator? floatingActionButtonAnimator;
  final List<Widget>? persistentFooterButtons;
  final AlignmentDirectional persistentFooterAlignment;
  final Widget? drawer;
  final DrawerCallback? onDrawerChanged;
  final Widget? endDrawer;
  final DrawerCallback? onEndDrawerChanged;
  final Widget? bottomNavigationBar;
  final Widget? bottomSheet;
  final Color? backgroundColor;
  final bool resizeToAvoidBottomInset;
  final double? titleSize, bodyMarginTop;
  final bool primary;
  final DragStartBehavior drawerDragStartBehavior;
  final bool extendBody;
  final IconData? backIcon;
  final bool showBackIcon, enableSafeArea, enableMarquee;
  final void Function()? onBackPressed;
  final String background;
  final String? title;
  final List<Widget>? actions;

  const CommonScaffold({
    super.key,
    this.body,
    this.onBackPressed,
    this.backIcon,
    this.enableMarquee = false,
    this.floatingActionButton,
    this.floatingActionButtonLocation,
    this.floatingActionButtonAnimator,
    this.persistentFooterButtons,
    this.bodyMarginTop,
    this.persistentFooterAlignment = AlignmentDirectional.centerEnd,
    this.drawer,
    this.onDrawerChanged,
    this.endDrawer,
    this.onEndDrawerChanged,
    this.bottomNavigationBar,
    this.bottomSheet,
    this.backgroundColor,
    this.resizeToAvoidBottomInset = true,
    this.titleSize,
    this.showBackIcon = false,
    this.enableSafeArea = true,
    this.primary = true,
    this.drawerDragStartBehavior = DragStartBehavior.start,
    this.extendBody = false,
    this.background =Assets.icBackArrow,
    this.title,
    this.actions,
  });

  @override
  Widget build(BuildContext context) {
    final hasAppBar = title?.isNotEmpty == true;



    return Stack(
      children: [
        Positioned.fill(
          child: Image.asset(
            background,
            fit: BoxFit.cover,
          ),
        ),
        Scaffold(
          // backgroundColor: backgroundColor :,
          extendBodyBehindAppBar: hasAppBar,
          appBar: hasAppBar
              ? AppBar(
            // toolbarHeight: kToolbarHeight + 20,
            actions: actions,
            surfaceTintColor: AppColors.transparent,
            titleSpacing: 0,
            title:
            // enableMarquee
            //     ? MarqueeText(
            //         title!,
            //         style: context.appTextTheme.headlineMedium?.copyWith(
            //           fontWeight: FontWeight.w500,
            //           fontSize: titleSize ?? 22,
            //         ),
            //       )
            //     :
            Text(
              title!,
              style: context.appTextTheme.headlineMedium?.copyWith(
                fontWeight: FontWeight.w500,
                fontSize: titleSize ?? 22,
              ),
            ),
            leading: showBackIcon
                ? InkWell(
              borderRadius: 77.borderRadius,
              onTap: onBackPressed,
              child: Padding(
                padding: const EdgeInsets.all(4.0),
                child: Icon(
                  backIcon ?? Icons.arrow_back_ios_new_rounded,
                  color: AppColors.white,
                ),
              ),
            )
                : const SizedBox(),
            backgroundColor: Colors.transparent,
            // ✅ Transparent AppBar
            elevation: 0,
            centerTitle: true,
          )
              : null,
          floatingActionButton: floatingActionButton,
          floatingActionButtonLocation: floatingActionButtonLocation,
          floatingActionButtonAnimator: floatingActionButtonAnimator,
          persistentFooterButtons: persistentFooterButtons,
          persistentFooterAlignment: persistentFooterAlignment,
          drawer: drawer,
          onDrawerChanged: onDrawerChanged,
          endDrawer: endDrawer,
          onEndDrawerChanged: onEndDrawerChanged,
          bottomNavigationBar: bottomNavigationBar,
          bottomSheet: bottomSheet,
          backgroundColor: backgroundColor ?? AppColors.transparent,
          resizeToAvoidBottomInset: resizeToAvoidBottomInset,
          primary: primary,
          drawerDragStartBehavior: drawerDragStartBehavior,
          extendBody: extendBody,
          body: SafeArea(child: body!),

          //   Stack(
          //   children: [
          //     backgroundWidget,
          //     if (body != null)
          //       Container(
          //         margin: EdgeInsetsGeometry.only(top: bodyMarginTop ?? 15),
          //         padding: EdgeInsets.only(
          //           top: hasAppBar
          //               ? 0
          //               : 0,
          //         ),
          //         child: enableSafeArea
          //             ? AnnotatedRegion(
          //                 value: SystemUiOverlayStyle.light,
          //                 child: SafeArea(bottom: true, child: body!),
          //               )
          //             : body!,
          //       ),
          //   ],
          // ),
        ),
      ],
    );
  }
}
