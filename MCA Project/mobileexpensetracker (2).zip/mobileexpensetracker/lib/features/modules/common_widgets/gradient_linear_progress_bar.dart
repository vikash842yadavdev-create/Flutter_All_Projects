import 'package:flutter/material.dart';
import 'package:espenso/features/config/helper.dart';

class GradientLinearProgressBar extends StatefulWidget {
  final double height;
  final Gradient gradient;
  final Color bgColor;
  final double borderRadius; // now a double

  const GradientLinearProgressBar({
    super.key,
    this.height = 6.0,
    this.bgColor = AppColors.transparent,
    required this.gradient,
    this.borderRadius = 4.0, // default corner radius
  });

  @override
  State<GradientLinearProgressBar> createState() =>
      _GradientIndeterminateProgressBarState();
}

class _GradientIndeterminateProgressBarState
    extends State<GradientLinearProgressBar>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    )..repeat(); // loop forever
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(widget.borderRadius),
      child: SizedBox(
        height: widget.height,
        child: AnimatedBuilder(
          animation: _controller,
          builder: (context, child) {
            return ShaderMask(
              shaderCallback: (bounds) {
                return widget.gradient.createShader(
                  Rect.fromLTWH(
                    -bounds.width + (bounds.width * 2 * _controller.value),
                    0,
                    bounds.width,
                    bounds.height,
                  ),
                );
              },
              child: LinearProgressIndicator(
                backgroundColor: widget.bgColor,
                valueColor: const AlwaysStoppedAnimation<Color>(Colors.white),
                value: null,
              ),
            );
          },
        ),
      ),
    );
  }
}
