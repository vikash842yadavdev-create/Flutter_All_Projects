import 'package:flutter/material.dart';
import 'package:espenso/features/config/helper.dart';
import 'package:espenso/features/modules/common_widgets/common_image_widget.dart';

class ImageViewerScreen extends StatefulWidget {
  final List<String> images;
  final int initialIndex;

  const ImageViewerScreen({
    super.key,
    required this.images,
    this.initialIndex = 0,
  });

  @override
  State<ImageViewerScreen> createState() => _ImageGalleryDialogState();
}

class _ImageGalleryDialogState extends State<ImageViewerScreen>
    with TickerProviderStateMixin {
  late PageController _pageController;
  late List<TransformationController> _controllers;
  late List<AnimationController> _animationControllers;
  late List<Animation<Matrix4>?> _animations;

  final double _scale = 2.5;
  final Matrix4 _identity = Matrix4.identity();
  int _currentPage = 0;

  @override
  void initState() {
    super.initState();
    _pageController = PageController(initialPage: widget.initialIndex);
    _currentPage = widget.initialIndex;

    _controllers = List.generate(
      widget.images.length,
      (_) => TransformationController(),
    );
    _animationControllers = List.generate(
      widget.images.length,
      (_) => AnimationController(
        vsync: this,
        duration: const Duration(milliseconds: 300),
      ),
    );
    _animations = List.generate(widget.images.length, (_) => null);
    // Utils.changeStatusBarColor(statusBarColor: AppColors.black);
  }

  void _handleDoubleTapDown(TapDownDetails details) {
    final controller = _controllers[_currentPage];
    final animationController = _animationControllers[_currentPage];
    final position = details.localPosition;

    final isZoomed = controller.value != _identity;

    final Matrix4 begin = controller.value;
    final Matrix4 end;

    if (isZoomed) {
      end = _identity;
    } else {
      final x = -position.dx * (_scale - 1);
      final y = -position.dy * (_scale - 1);
      end = Matrix4.identity()
        ..translate(x, y)
        ..scale(_scale);
    }

    final animation = Matrix4Tween(begin: begin, end: end).animate(
      CurvedAnimation(parent: animationController, curve: Curves.easeInOut),
    );

    _animations[_currentPage] = animation;
    animationController.reset();
    animationController.forward();

    animationController.addListener(() {
      controller.value = animation.value;
    });
  }

  @override
  void dispose() {
    for (var c in _controllers) {
      c.dispose();
    }
    for (var a in _animationControllers) {
      a.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.black,
      body: SafeArea(
        child: Stack(
          children: [
            PageView.builder(
              controller: _pageController,
              itemCount: widget.images.length,
              onPageChanged: (index) {
                setState(() {
                  _currentPage = index;
                });
              },
              itemBuilder: (context, index) {
                return GestureDetector(
                  onDoubleTapDown: _handleDoubleTapDown,
                  onDoubleTap: () {},
                  child: Center(
                    child: InteractiveViewer(
                      transformationController: _controllers[index],
                      panEnabled: true,
                      scaleEnabled: true,
                      minScale: 1,
                      maxScale: 4,
                      child: CommonImageWidget(
                        img: widget.images[index],
                        height: context.height,
                        width: context.width,
                        fit: BoxFit.contain,
                      ),
                    ),
                  ),
                );
              },
            ),
            Positioned(
              top: 40,
              right: 20,
              child: GestureDetector(
                onTap: () {
                  back(context);
                },
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.black.withValues(alpha: 0.7),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.close, color: Colors.white),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
