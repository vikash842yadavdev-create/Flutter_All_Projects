import 'package:flutter/material.dart';
import 'package:espenso/features/modules/common_widgets/common_image_widget.dart';

class TransactionTile extends StatelessWidget {
  final String title;
  final String date;
  final String amount;
  final String image;
  final bool isIncome;

  const TransactionTile({
    super.key,
    required this.title,
    required this.date,
    required this.amount,
    required this.image,
    required this.isIncome,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      contentPadding: EdgeInsets.zero,

      leading: Container(
        height: 50,
        width: 50,
        padding: const EdgeInsets.all(3),
        decoration: BoxDecoration(
          color: const Color(0xffF3F5F5),
          borderRadius: BorderRadius.circular(15),
        ),
        child: CommonImageWidget(img: image,fit: BoxFit.cover,)
      ),

      title: Text(
        title,
        style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
      ),

      subtitle: Text(
        date,
        style: const TextStyle(color: Colors.grey, fontSize: 13),
      ),

      trailing: Text(
        "${isIncome ? '+' : '-'} \$ $amount",
        style: TextStyle(
          color: isIncome ? const Color(0xff4CAF50) : const Color(0xffFF6B6B),
          fontWeight: FontWeight.bold,
          fontSize: 18,
        ),
      ),
    );
  }
}
