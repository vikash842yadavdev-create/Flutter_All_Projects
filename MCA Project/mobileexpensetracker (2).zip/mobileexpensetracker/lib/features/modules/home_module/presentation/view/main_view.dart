import 'package:espenso/features/modules/home_module/presentation/controller/bottomnav_controller.dart';
import 'package:espenso/features/modules/home_module/presentation/view/home_view.dart';
import 'package:espenso/features/modules/home_module/presentation/view/stats_view.dart';
import 'package:espenso/features/modules/home_module/presentation/widget/custom_bottom_nav_widget.dart';
import 'package:espenso/features/modules/profile_module/presentation/view/profile_view.dart';
import 'package:espenso/features/modules/wallet_module/presentation/view/wallet_main_view.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class MainView extends StatefulWidget {
  const MainView({super.key});

  @override
  State<MainView> createState() => _MainViewState();
}

class _MainViewState extends State<MainView> {
  final BottomNavController controller = Get.find<BottomNavController>();

  @override
  Widget build(BuildContext context) {
    final pages = [
      const HomeView(),
      const StatsView(),
      const WalletMainView(),
      const ProfileView(),
    ];

    return Obx(
      () => Scaffold(
        body: pages[controller.selectedIndex.value],

        floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,

        floatingActionButton: controller.selectedIndex.value == 0
            ? Container(
                height: 75,
                width: 75,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(
                      blurRadius: 10,
                      color: Colors.black.withValues(alpha: .15),
                    ),
                  ],
                ),
                child: FloatingActionButton(
                  elevation: 0,
                  backgroundColor: const Color(0xff4E9F8E),
                  shape: const CircleBorder(),
                  onPressed: () {},
                  child: const Icon(Icons.add, size: 35, color: Colors.white),
                ),
              )
            : null,

        bottomNavigationBar: const CustomBottomNav(),
      ),
    );
  }
}




// controller.selectedIndex.value == 0 ||
// controller.selectedIndex.value == 2


//  return Obx(
//       () => Scaffold(
//         body: pages[controller.selectedIndex.value],

//         floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,

//         floatingActionButton: Container(
//           height: 75,
//           width: 75,
//           decoration: BoxDecoration(
//             shape: BoxShape.circle,
//             color: Colors.white,
//             boxShadow: [
//               BoxShadow(blurRadius: 10, color: Colors.black.withOpacity(.15)),
//             ],
//           ),
//           child: FloatingActionButton(
//             elevation: 0,
//             backgroundColor: const Color(0xff4E9F8E),
//             shape: const CircleBorder(),
//             onPressed: () {
//               /// Add Expense Screen
//             },
//             child: const Icon(Icons.add, size: 35, color: Colors.white),
//           ),
//         ),

//         bottomNavigationBar: const CustomBottomNav(),
//       ),
//     );
