import 'package:get/get.dart';
import 'package:espenso/features/modules/home_module/presentation/controller/bottomnav_controller.dart';

class BottomNavBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<BottomNavController>(() => BottomNavController());
  }
}
