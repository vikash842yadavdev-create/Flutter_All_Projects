import 'package:flutter/material.dart';
import 'package:espenso/features/modules/common_widgets/common_image_widget.dart';

class RecentContactsWidget extends StatelessWidget {
  final List<String> images;
  final double size;
  final double spacing;

  const RecentContactsWidget({
    super.key,
    required this.images,
    this.size = 62,
    this.spacing = 3,
  });

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: List.generate(
          images.length,
          (index) => Padding(
            padding: EdgeInsets.only(
              right: index == images.length - 1 ? 0 : spacing,
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(size / 2),
              child: CommonImageWidget(
                img: images[index],
                height: size,
                width: size,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
