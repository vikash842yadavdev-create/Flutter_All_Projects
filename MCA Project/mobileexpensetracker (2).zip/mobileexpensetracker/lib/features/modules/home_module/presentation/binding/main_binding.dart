import 'package:get/get.dart';
import 'package:espenso/features/modules/home_module/presentation/controller/main_controller.dart';

class MainBinding extends Bindings {
  @override
  void dependencies() {
    // Get.lazyPut<BottomNavController>(() => BottomNavController());
    Get.lazyPut<MainController>(() => MainController());
  }
}
