import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:espenso/features/config/assets.dart';
import 'package:espenso/features/config/helper.dart';
import 'package:espenso/features/modules/common_widgets/common_text_widget.dart';
import 'package:espenso/features/modules/home_module/presentation/controller/home_controller.dart';
import 'package:espenso/features/modules/home_module/presentation/widget/CommonSectionHeader_widget.dart';
import 'package:espenso/features/modules/home_module/presentation/widget/balancecard_widget.dart';
import 'package:espenso/features/modules/home_module/presentation/widget/recent_contacts_widget.dart';
import 'package:espenso/features/modules/home_module/presentation/widget/transaction_list_widget.dart';

class HomeView extends StatefulWidget {
  const HomeView({super.key});

  @override
  State<HomeView> createState() => _HomeViewState();
}

class _HomeViewState extends State<HomeView> {
  final HomeController controller = Get.put(HomeController());
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Container(
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage(Assets.imgBackground),
              fit: BoxFit.cover,
            ),
          ),
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                children: [
                  /// Header
                  const SizedBox(height: 20),

                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          CommonText("Good Morning", color: AppColors.white),
                          CommonText(
                            "Vikash Yadav",
                            color: AppColors.white,
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ],
                      ),

                      Container(
                        height: 40,
                        width: 40,
                        decoration: BoxDecoration(
                          color: AppColors.secondary,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Icon(
                          Icons.notifications_outlined,
                          color: AppColors.white,
                          size: 28,
                        ),
                      ),
                    ],
                  ),

                  25.pixelH,

                  /// Balance Card
                  Obx(
                    () => BalanceCardWidget(
                      totalBalance: controller.totalBalance.value,
                      income: controller.totalIncome.value,
                      expense: controller.totalExpense.value,
                    ),
                  ),

                  25.pixelH,

                  /// Other widgets here
                  CommonSectionHeader(
                    title: "Transactions history",
                    actionText: "See all",
                    onTap: () {},
                  ),
                  10.pixelH,

                  TransactionList(),

                  10.pixelH,

                  CommonSectionHeader(
                    title: "Send Again",
                    actionText: "See all",
                    onTap: () {},
                  ),

                  10.pixelH,

                  // Obx(() => RecentContactsWidget(images: controller.contacts)),
                  RecentContactsWidget(
                    images: [
                      Assets.imgTpersons1,
                      Assets.imgTpersons2,
                      Assets.imgTpersons3,
                      Assets.imgTpersons4,
                      Assets.imgTpersons5,
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
