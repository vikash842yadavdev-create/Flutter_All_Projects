import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:espenso/features/modules/home_module/presentation/controller/home_controller.dart';
import 'package:espenso/features/modules/home_module/presentation/widget/transaction_tile_widget.dart';


class TransactionList extends GetView<HomeController> {
  const TransactionList({super.key});

  @override
  Widget build(BuildContext context) {
    return Obx(
      () => ListView.builder(
        padding: EdgeInsets.zero,
        itemCount: controller.transactions.length,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemBuilder: (context, index) {
          final transaction = controller.transactions[index];

          return TransactionTile(
            title: transaction.title,
            date: transaction.date,
            amount: transaction.amount,
            image: transaction.image,
            isIncome: transaction.isIncome,
          );
        },
      ),
    );
  }
}
