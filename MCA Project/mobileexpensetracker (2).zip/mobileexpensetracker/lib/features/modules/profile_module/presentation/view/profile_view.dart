import 'package:espenso/features/modules/common_widgets/common_small_widgets/custom_headerbar_widget.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:espenso/features/config/assets.dart';
import 'package:espenso/features/config/helper.dart';
import 'package:espenso/features/modules/common_widgets/common_image_widget.dart';
import 'package:espenso/features/modules/common_widgets/common_text_widget.dart';
import 'package:espenso/features/modules/profile_module/presentation/controller/profile_controller.dart';
import 'package:espenso/features/modules/profile_module/presentation/widget/profile_menu_tile.dart';

class ProfileView extends StatefulWidget {
  const ProfileView({super.key});

  @override
  State<ProfileView> createState() => _ProfileViewState();
}

class _ProfileViewState extends State<ProfileView> {
  @override
  Widget build(BuildContext context) {
    final ProfileController controller = Get.put(ProfileController());
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage(Assets.imgBackground),
            fit: BoxFit.cover,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 25),
          child: Column(
            children: [
              50.pixelH,

              CustomHeaderBar(
                title: "Profile",
                actionIcon: Icons.notifications_outlined,
                backgroundColor: AppColors.transparent,
              ),

              45.pixelH,

              CommonImageWidget(
                img: Assets.imgProfileDummy,
                height: 120,
                width: double.infinity,
                fit: BoxFit.contain,
              ),
              CommonText(
                "Vikash Yadav",
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
              CommonText("@vikash123yadav", fontSize: 14),
              Expanded(
                child: Obx(
                  () => ListView.builder(
                    itemCount: controller.menuItems.length,
                    itemBuilder: (context, index) {
                      final item = controller.menuItems[index];

                      return Column(
                        children: [
                          ProfileMenuTile(
                            icon: item.icon,
                            title: item.title,
                            onTap: item.onTap,
                          ),

                          if (index == 0)
                            const Divider(thickness: 1, height: 1),
                        ],
                      );
                    },
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
