package com.example.espenso

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
