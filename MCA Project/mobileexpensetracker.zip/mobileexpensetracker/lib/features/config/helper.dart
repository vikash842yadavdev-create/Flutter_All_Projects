import 'dart:developer';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:mobileexpensetracker/features/config/theme.dart';
import 'package:mobileexpensetracker/features/modules/common_widgets/loader.dart';

part 'app_colors.dart';
part 'extensions.dart';

void exit() {
  SystemNavigator.pop();
}

double screenWidth(BuildContext context) {
  return MediaQuery.of(context).size.width;
}

double screenHeight(BuildContext context) {
  return MediaQuery.of(context).size.height;
}

double safeAreaHeight(BuildContext context) {
  return (MediaQuery.of(context).padding.top) /*+
          MediaQuery.of(context).padding.bottom)*/ +
      15;
}

void unFocus(BuildContext context) {
  FocusScope.of(context).unfocus();
}

SizedBox yHeight(double height) {
  return SizedBox(height: height);
}

SizedBox xWidth(double width) {
  return SizedBox(width: width);
}

Future<dynamic> pushTo(BuildContext context, Widget widget) async {
  return await Navigator.push(
    context,
    MaterialPageRoute(builder: (context) => widget),
  );
}

void pushReplacement(BuildContext context, Widget widget) {
  Navigator.pushReplacement(
    context,
    MaterialPageRoute(builder: (context) => widget),
  );
}

void pushRemoveUtil(BuildContext context, Widget widget) {
  Navigator.pushAndRemoveUntil(
    context,
    MaterialPageRoute(builder: (context) => widget),
    (route) {
      return false;
    },
  );
}

void offAllNamed(BuildContext context, String routesName) {
  Navigator.pushNamedAndRemoveUntil(
    context,
    routesName,
    (Route<dynamic> route) => false,
  );
}

Future<dynamic> toNamed(
  BuildContext context,
  String routesName, {
  Object? args,
}) async {
  return Navigator.pushNamed(context, routesName, arguments: args);
}

void back(BuildContext context, {dynamic result, int times = 1}) {
  if (times > 1) {
    int count = 0;
    Navigator.of(context).popUntil((_) => count++ >= times);
  } else {
    Navigator.pop(context, result);
  }
}

void backWithoutContext({dynamic result, int times = 1}) {
  var context = LoaderManager.navigatorKey.currentState?.context;

  if (times > 1) {
    int count = 0;
    Navigator.of(context!).popUntil((_) => count++ >= times);
  } else {
    Navigator.pop(context!, result);
  }
}

logConsole(dynamic object, {dynamic tag, bool ignorePrint = false}) {
  if (ignorePrint) {
    return;
  }

  tag = "${tag ?? ""}";

  if (object.toString().isNotEmpty) {
    log(
      object.toString(),
      name: tag.isNotEmpty
          ? tag.toString().replaceAll("Instance of ", "").replaceAll("'", "")
          : "Connect",
    );
  }
}

bool emailValidation(String email) {
  Pattern pattern =
      r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';
  RegExp regex = RegExp(pattern.toString());
  return regex.hasMatch(email);
}

String formatTime12Hour(TimeOfDay time) {
  int hour = time.hour % 12;
  if (hour == 0) hour = 12; // 12 instead of 0
  final minute = time.minute.toString().padLeft(2, '0');

  return '$hour:$minute'; // 12-hour format, no AM/PM
}
