part of 'app_pages.dart';

abstract class Routes {
  static const splashView = _Paths.splashView;
  static const onboardingView = _Paths.onboardingView;
  static const signUpView = _Paths.signUpView;
  static const loginView = _Paths.loginView;
  static const mainView = _Paths.mainView;
  static const homeView = _Paths.homeView;
   static const transactionDetailsView = _Paths.transactionDetailsView;

}

abstract class _Paths {
  static const splashView = '/splashView';
  static const onboardingView = '/onboardingView';
  static const signUpView = '/signupView';
  static const loginView = '/loginView';
  static const mainView = '/mainView';
  static const homeView = '/homeView';
  static const transactionDetailsView = '/transactionDetailsView';

}
