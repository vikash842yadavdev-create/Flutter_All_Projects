import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:mobileexpensetracker/features/modules/auth_module/presentation/binding/login_binding.dart';
import 'package:mobileexpensetracker/features/modules/auth_module/presentation/binding/signup_binding.dart';
import 'package:mobileexpensetracker/features/modules/auth_module/presentation/view/login_view.dart';
import 'package:mobileexpensetracker/features/modules/auth_module/presentation/view/signup_view.dart';
import 'package:mobileexpensetracker/features/modules/home_module/presentation/binding/bottomnav_binding.dart';
import 'package:mobileexpensetracker/features/modules/home_module/presentation/binding/home_binding.dart';
import 'package:mobileexpensetracker/features/modules/home_module/presentation/binding/main_binding.dart';
import 'package:mobileexpensetracker/features/modules/home_module/presentation/view/home_view.dart';
import 'package:mobileexpensetracker/features/modules/home_module/presentation/view/main_view.dart';
import 'package:mobileexpensetracker/features/modules/onboarding_module/presentation/binding/onboarding_binding.dart';
import 'package:mobileexpensetracker/features/modules/onboarding_module/presentation/binding/splash_binding.dart';
import 'package:mobileexpensetracker/features/modules/onboarding_module/presentation/view/onboarding_view.dart';
import 'package:mobileexpensetracker/features/modules/onboarding_module/presentation/view/splash_view.dart';
import 'package:mobileexpensetracker/features/modules/wallet_module/presentation/binding/transaction_details_binding.dart';
import 'package:mobileexpensetracker/features/modules/wallet_module/presentation/view/wallet_home_view/wallet_transactions_views/transaction_details_view.dart';

part 'app_routes.dart';

abstract class AppPages {
  static const initialPage = Routes.splashView;

  static List<GetPage<dynamic>> routes = [
    getPage(
      name: _Paths.splashView,
      page: const SplashView(),
      binding: SplashBinding(),
    ),
    getPage(
      name: _Paths.onboardingView,
      page: const OnboardingView(),
      binding: OnboardingBinding(),
    ),
    getPage(
      name: _Paths.signUpView,
      page: const SignUpView(),
      binding: SignUpBinding(),
    ),
    getPage(
      name: _Paths.loginView,
      page: const LoginView(),
      binding: LoginBinding(),
    ),
    getPage(
      name: _Paths.mainView,
      page: const MainView(),
      bindings: [MainBinding(), BottomNavBinding()],
    ),
    getPage(
      name: _Paths.homeView,
      page: const HomeView(),
      binding: HomeBinding(),
    ),
  //   getPage(
  //     name: _Paths.transactionDetailsView,
  //     page: const TransactionDetailsView(),
  //     binding: TransactionDetailsBinding(),
  //   ),
  ];
}

GetPage<dynamic> getPage({
  required String name,
  required Widget page,
  Bindings? binding,
  Transition? transition,
  List<Bindings>? bindings,
}) {
  return GetPage(
    name: name,
    page: () => page,
    binding: binding,
    transition: transition,
    bindings: bindings ?? [],
  );
}
