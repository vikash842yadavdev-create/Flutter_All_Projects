
import 'package:mobileexpensetracker/features/modules/common_widgets/country_code_picker/countries_list.dart';



abstract class AppConstants {
  static const String oxanium = "Oxanium";
  static const String rajdhani = "Rajdhani";

  // -----   App Fonts Family Constants ----- ///



  static Country defaultCountry = Country(
    name: "United States",
    flag: "🇺🇸",
    code: "US",
    dialCode: "+1",
    minLength: 10,
    maxLength: 10,
  );
}
