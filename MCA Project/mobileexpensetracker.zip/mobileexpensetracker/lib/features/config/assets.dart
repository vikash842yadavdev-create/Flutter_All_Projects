class Assets {
  static const String imgPath = "assets/images";
  static const String icBackArrow = "assets/images/ic_back_arrow.png";

  //Images
  static const String imgOnboardingBackground = "$imgPath/onboarding_bg.png";
  static const String imgOnboardingMan = "$imgPath/onboarding_man.png";
  static const String imgOnboardingCoin = "$imgPath/onboarding_coin.png";
  static const String imgOnboardingDonut = "$imgPath/onboarding_donut.png";
  static String imgBackground = "$imgPath/background.png";
  static String imgBackground2 = "$imgPath/background2.png";
  static String imgProfileDummy = "$imgPath/profile_dummy.png";

  static String imgTUpwork = "$imgPath/t1.png";
  static String imgTPerson = "$imgPath/t2.png";
  static String imgTPaypal = "$imgPath/t3.png";
  static String imgTYoutube = "$imgPath/t4.png";

  static String imgTpersons1 = "$imgPath/p1.png";
  static String imgTpersons2 = "$imgPath/p2.png";
  static String imgTpersons3 = "$imgPath/p3.png";
  static String imgTpersons4 = "$imgPath/p4.png";
  static String imgTpersons5 = "$imgPath/p5.png";

  static String imgVector = "$imgPath/Vector.png";
}
