part of 'helper.dart';

abstract final class AppColors {
  static const primary = Color(0xFF4E9691);
  static const secondary = Color(0xFF438883);
  static const transparent = Color(0x00000000);
  static const active = Color(0xFF4CD201);
  static const black = Colors.black;
  static const textfield_primary=Color(0xFF838383);
  static const white = Colors.white;
  static const red = Colors.red;

  static const linearGradient = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [Color(0xFF69AEA9), Color(0xFF3F8782)],
  );
}
