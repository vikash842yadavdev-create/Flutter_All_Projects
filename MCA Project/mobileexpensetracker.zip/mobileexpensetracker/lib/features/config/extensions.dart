part of 'helper.dart';


extension StringCasingExtension on String {
  String toCapitalized() =>
      length > 0 ? '${this[0].toUpperCase()}${substring(1).toLowerCase()}' : '';

  String toTitleCase() => replaceAll(
    RegExp(' +'),
    ' ',
  ).split(' ').map((str) => str.toCapitalized()).join(' ');
}

// extension ProfilePaths on String {
//   String get withProfileUrl => "${ApiConstants.userProfileImg}$this";

//   String get withDriverProfileUrl => "${ApiConstants.driverProfileImg}$this";
// }


extension AlignExtension on Widget {
  Widget align({AlignmentGeometry alignment = Alignment.center}) {
    return Align(
      alignment: alignment,
      child:
          this, // 'this' refers to the widget you're calling the extension on
    );
  }
}

extension BorderRadiusCircular on num {

  BorderRadius get borderRadius {
    return BorderRadius.circular(toDouble());
  }
  BorderRadiusGeometry get circularBorder {
    return BorderRadius.all(Radius.circular(toDouble()));
  }
}


extension UrlCheckExtension on String {
  bool get isURL {
    final pattern =
        r"^((((H|h)(T|t)|(F|f))(T|t)(P|p)((S|s)?))\://)?(www.|[a-zA-Z0-9].)[a-zA-Z0-9\-\.]+\.[a-zA-Z]{2,6}(\:[0-9]{1,5})*(/($|[a-zA-Z0-9\.\,\;\?\'\\\+&amp;%\$#\=~_\-]+))*$";
    final regExp = RegExp(pattern);
    return regExp.hasMatch(this);
  }


  String timeAgo() {
    try {
      // Ensure UTC parsing
      DateTime utcTime = DateTime.parse(
        contains('Z') ? this : "${replaceAll(' ', 'T')}Z",
      ).toUtc();

      DateTime local = utcTime.toLocal();

      Duration diff = DateTime.now().difference(local);

      if (diff.inSeconds < 60) {
        return "Just now";
      } else if (diff.inMinutes < 60) {
        return "${diff.inMinutes} minute${diff.inMinutes == 1 ? '' : 's'} ago";
      } else if (diff.inHours < 24) {
        return "${diff.inHours} hour${diff.inHours == 1 ? '' : 's'} ago";
      } else if (diff.inDays == 1) {
        return "yesterday";
      } else if (diff.inDays < 7) {
        return "${diff.inDays} day${diff.inDays == 1 ? '' : 's'} ago";
      } else {
        return "${local.day.toString().padLeft(2, '0')}-"
            "${local.month.toString().padLeft(2, '0')}-"
            "${local.year}";
      }
    } catch (e) {
      return "";
    }
  }
}

extension DateShortFormat on String {
  String toMonthYearShort() {
    try {
      // Normalize delimiters
      final normalized = replaceAll('/', '-');
      final parts = normalized.split('-');

      late DateTime date;

      if (parts.length == 3) {
        // Detect if format is dd-MM-yyyy or yyyy-MM-dd
        if (parts[0].length == 4) {
          // yyyy-MM-dd
          date = DateTime(
            int.parse(parts[0]),
            int.parse(parts[1]),
            int.parse(parts[2]),
          );
        } else {
          // dd-MM-yyyy
          date = DateTime(
            int.parse(parts[2]),
            int.parse(parts[1]),
            int.parse(parts[0]),
          );
        }
      } else {
        throw FormatException("Unsupported date format: $this");
      }

      final month = date.month.toString().padLeft(2, '0');
      final year = date.year.toString().substring(2);
      return '$month/$year';
    } catch (e) {
      logConsole(e.runtimeType, tag: e);
      return this;
    }
  }


  String formatTime() {
    try {
      final parts = split(':');
      if (parts.length < 2) return this;

      int hour = int.parse(parts[0]);
      int minute = int.parse(parts[1]);

      final period = hour >= 12 ? ' PM' : ' AM';
      hour = hour % 12 == 0 ? 12 : hour % 12;

      final formatted =
          '${hour.toString().padLeft(2, '0')}:${minute.toString().padLeft(2, '0')}$period';

      return formatted;
    } catch (e) {
      return this; // fallback in case of invalid input
    }
  }
}

extension DateTimeStringFormatter on String {
  String toDateTimeFormatted() {
    try {
      final dateTime = DateTime.parse(this);
      // Format to YYYY-MM-DD H:i:s
      return '${dateTime.year.toString().padLeft(4, '0')}-'
          '${dateTime.month.toString().padLeft(2, '0')}-'
          '${dateTime.day.toString().padLeft(2, '0')} '
          '${dateTime.hour.toString().padLeft(2, '0')}:'
          '${dateTime.minute.toString().padLeft(2, '0')}:'
          '${dateTime.second.toString().padLeft(2, '0')}';
    } catch (_) {
      return this; // fallback if parse fails
    }
  }
}

extension ToStringAsFixed on String {
  String get toStringAsFixed {
    return (double.tryParse(this) ?? 0).toStringAsFixed(1);
  }
}

extension TrimExtension on String {
  String trimTo(int length) {
    if (length <= 0) return '';
    if (length >= this.length) return this;
    return substring(0, length);
  }
}

extension DelayExtension on num {
  Future<void> delay(VoidCallback callback) async {
    await Future.delayed(Duration(milliseconds: (this * 1000).toInt()));
    callback();
  }
}

extension CardMasking on String {
  String toMaskedCardFormat() {
    if (length < 6) return this; // Not enough digits to mask

    // Keep last 6 digits, mask the rest
    String visiblePart = substring(length - 6);
    String masked = '*' * (length - 6);

    // Add spaces every 2 digits in the visible part
    String spacedVisible = '';
    for (int i = 0; i < visiblePart.length; i += 2) {
      if (i + 2 <= visiblePart.length) {
        spacedVisible += visiblePart.substring(i, i + 2);
      } else {
        spacedVisible += visiblePart.substring(i);
      }
      if (i + 2 < visiblePart.length) spacedVisible += ' ';
    }

    return '$masked$spacedVisible';
  }
}

extension ContextExtension on BuildContext {
  double get height => MediaQuery.of(this).size.height;

  double get width => MediaQuery.of(this).size.width;
}

extension EmptyPadding on num {
  SizedBox get pixelH => SizedBox(height: toDouble());

  SizedBox get pixelW => SizedBox(width: toDouble());
}

extension ThemeExtension on BuildContext {
  TextTheme get appTextTheme => AppTheme().getTheme().textTheme;

  Color get primaryColor => AppTheme().getTheme().primaryColor;

  ColorScheme get colorScheme => AppTheme().getTheme().colorScheme;

  Brightness get brightness => AppTheme().getTheme().brightness;
}
