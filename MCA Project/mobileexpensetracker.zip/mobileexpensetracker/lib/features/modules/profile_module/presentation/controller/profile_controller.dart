import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:mobileexpensetracker/features/modules/profile_module/data/models/profile_menu_model.dart';

class ProfileController extends GetxController {
  final menuItems = <ProfileMenuModel>[
    ProfileMenuModel(icon: Icons.diamond_sharp, title: "Invite Friends"),

    ProfileMenuModel(icon: Icons.person_2_rounded, title: "Account Info"),

    ProfileMenuModel(icon: Icons.people_alt, title: "Personal Profile"),

    ProfileMenuModel(icon: Icons.mail_outline_rounded, title: "Message Center"),

    ProfileMenuModel(icon: Icons.security, title: "Login and Security"),

    ProfileMenuModel(icon: Icons.lock_outline, title: "Data and Privacy"),
  ].obs;
}
