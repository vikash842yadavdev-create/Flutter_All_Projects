import 'package:flutter/material.dart';
class ProfileMenuModel {
  final IconData icon;
  final String title;
  final VoidCallback? onTap;

  ProfileMenuModel({required this.icon, required this.title, this.onTap});
}
