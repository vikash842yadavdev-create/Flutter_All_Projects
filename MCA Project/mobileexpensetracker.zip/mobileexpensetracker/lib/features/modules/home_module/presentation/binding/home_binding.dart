
import 'package:get/get.dart';
import 'package:mobileexpensetracker/features/modules/home_module/presentation/controller/home_controller.dart';

class HomeBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<HomeController>(() => HomeController());
  }
}
