import 'package:get/get.dart';
import 'package:mobileexpensetracker/features/config/assets.dart';
import 'package:mobileexpensetracker/features/modules/home_module/data/models/transaction_model.dart';

class HomeController extends GetxController {
  RxDouble totalBalance = 2548.00.obs;
  RxDouble totalIncome = 1840.00.obs;
  RxDouble totalExpense = 284.00.obs;

  // RxList<String> contacts = [
  //   Assets.imgTpersons1,
  //   Assets.imgTpersons2,
  //   Assets.imgTpersons3,
  //   Assets.imgTpersons4,
  //   Assets.imgTpersons5,
  // ].obs;


  RxList<TransactionModel> transactions = <TransactionModel>[
    TransactionModel(
      title: "Upwork",
      date: "Today",
      amount: "850.00",
      image: Assets.imgTUpwork,
      isIncome: true,
    ),

    TransactionModel(
      title: "Transfer",
      date: "Yesterday",
      amount: "85.00",
      image: Assets.imgTPerson,
      isIncome: false,
    ),

    TransactionModel(
      title: "Paypal",
      date: "Jan 30, 2022",
      amount: "1406.00",
      image: Assets.imgTPaypal,
      isIncome: true,
    ),

    TransactionModel(
      title: "Youtube",
      date: "Jan 16, 2022",
      amount: "11.99",
      image: Assets.imgTYoutube,
      isIncome: false,
    ),
  ].obs;
}
