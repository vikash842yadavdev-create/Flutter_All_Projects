import 'package:flutter/material.dart';

class BalanceCardWidget extends StatelessWidget {
  final double totalBalance;
  final double income;
  final double expense;

  const BalanceCardWidget({
    super.key,
    required this.totalBalance,
    required this.income,
    required this.expense,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      height: 180,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xff438883),
        borderRadius: BorderRadius.circular(28),
        boxShadow: [
          BoxShadow(
            color: const Color(0xff438883).withValues(alpha: .35),
            blurRadius: 30,
            spreadRadius: 8,
            offset: const Offset(0, 18),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Text(
                "Total Balance",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                ),
              ),
              SizedBox(width: 5),
              Icon(Icons.keyboard_arrow_up, color: Colors.white, size: 18),
              Spacer(),
              Icon(Icons.more_horiz, color: Colors.white, size: 20),
            ],
          ),

          const SizedBox(height: 5),

          Text(
            "\$${totalBalance.toStringAsFixed(2)}",
            style: const TextStyle(
              color: Colors.white,
              fontSize: 28,
              fontWeight: FontWeight.bold,
            ),
          ),

          const SizedBox(height: 15),

          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _item(
                icon: Icons.arrow_downward,
                title: "Income",
                amount: income,
              ),

              _item(
                icon: Icons.arrow_upward,
                title: "Expenses",
                amount: expense,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _item({
    required IconData icon,
    required String title,
    required double amount,
  }) {
    return Row(
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 12,
                  backgroundColor: Colors.white24,
                  child: Icon(icon, size: 14, color: Colors.white),
                ),
                SizedBox(width: 5),
                Text(
                  title,
                  style: const TextStyle(color: Colors.white70, fontSize: 12),
                ),
              ],
            ),
            SizedBox(height: 4),
            Text(
              "\$${amount.toStringAsFixed(2)}",
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w700,
                fontSize: 18,
              ),
            ),
          ],
        ),
      ],
    );
  }
}
