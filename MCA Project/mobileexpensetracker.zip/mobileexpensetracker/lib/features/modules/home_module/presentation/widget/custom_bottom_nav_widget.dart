import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:mobileexpensetracker/features/modules/home_module/presentation/controller/bottomnav_controller.dart';

class CustomBottomNav extends GetView<BottomNavController> {
  const CustomBottomNav({super.key});

  @override
  Widget build(BuildContext context) {
    return BottomAppBar(
      shape: const CircularNotchedRectangle(),
      notchMargin: 4,
      color: Colors.white,
      elevation: 10,
      child: SizedBox(
        height: 70,
        child: Obx(
          () => Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _navItem(Icons.home_rounded, 0),

              _navItem(Icons.bar_chart_rounded, 1),

                AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                width: controller.selectedIndex.value == 0 ? 50 : 0,
              ),

              _navItem(Icons.account_balance_wallet_outlined, 2),

              _navItem(Icons.person_outline, 3),
            ],
          ),
        ),
      ),
    );
  }

  Widget _navItem(IconData icon, int index) {
    return GestureDetector(
      onTap: () {
        controller.changeTab(index);
      },
      child: Icon(
        icon,
        size: 28,
        color: controller.selectedIndex.value == index
            ? const Color(0xff4E9F8E)
            : Colors.grey,
      ),
    );
  }
}
