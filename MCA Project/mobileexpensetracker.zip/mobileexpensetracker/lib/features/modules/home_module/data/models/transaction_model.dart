class TransactionModel {
  final String title;
  final String date;
  final String amount;
  final String image;
  final bool isIncome;

  TransactionModel({
    required this.title,
    required this.date,
    required this.amount,
    required this.image,
    required this.isIncome,
  });
}
