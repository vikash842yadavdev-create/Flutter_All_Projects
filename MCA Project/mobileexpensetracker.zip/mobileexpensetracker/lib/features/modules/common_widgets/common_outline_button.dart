import 'package:flutter/material.dart';
import 'package:mobileexpensetracker/features/config/helper.dart';

class CommonOutlineButton extends StatelessWidget {
  final String text;
  final Color color;
  final Color borderColor;
  final Color textColor;
  final VoidCallback ontap;
  final Widget? prefix;
  final Widget? suffix;
  const CommonOutlineButton({
    super.key,
    required this.text,
    this.color = AppColors.transparent,
    this.borderColor = AppColors.primary,
    this.textColor = AppColors.primary,
    required this.ontap,
    this.prefix,
    this.suffix
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: ontap,
      borderRadius: BorderRadius.circular(100),
      child: Container(
        width: context.width,
        padding: EdgeInsets.all(18),
        decoration: BoxDecoration(color: color, borderRadius: 100.borderRadius,
        border: Border.all(color: borderColor)),
        child: Center(
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (prefix != null) prefix!,
              if(prefix!=null)
                8.pixelW,
              Text(
                text,
                style: context.appTextTheme.bodyLarge?.copyWith(
                  color: textColor,
                  fontWeight: FontWeight.w600,
                ),
              ), if(suffix!=null)
                8.pixelW,
              if (suffix != null) suffix!,
            ],
          ),
        ),
      ),
    );
  }
}
