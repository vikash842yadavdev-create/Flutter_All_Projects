// import 'package:connect/config/helper.dart';
// import 'package:connect/core/helpers/all_getter.dart';
// import 'package:flutter/material.dart';
//
// class CommonPicker {
//   static Future<DateTime?> showDatePickerDialog({
//     required BuildContext context,
//     required DateTime? firstDate,
//     required DateTime? lastDate,
//   }) async {
//     try {
//       return await showDatePicker(
//         context: context,
//         initialDate: Getters.now,
//         firstDate: firstDate ?? DateTime(1947),
//         lastDate: lastDate ?? Getters.now,
//         builder: (context, child) {
//           return Theme(
//             data: Theme.of(context).copyWith(
//               colorScheme: const ColorScheme.light(
//                 primary: AppColors.primary,
//                 onPrimary: AppColors.white,
//                 onSurface: AppColors.black,
//               ),
//               textButtonTheme: TextButtonThemeData(
//                 style: TextButton.styleFrom(foregroundColor: AppColors.primary),
//               ),
//             ),
//             child: child!,
//           );
//         },
//       );
//     } catch (e) {
//       functionLog(fun: "showDatePickerDialog", msg: e.toString());
//       return null;
//     }
//   }
// }
