import 'package:flutter/material.dart';
import 'package:mobileexpensetracker/features/config/helper.dart';
import 'package:mobileexpensetracker/features/modules/common_widgets/custom_toast.dart';


class CommonTimePicker {
  CommonTimePicker._();

  static Future<TimeOfDay?> pick({
    required BuildContext context,
    TimeOfDay? initialTime,
    TimeOfDay? minTime,
    Color? primaryColor,       // main color for picker
    Color? backgroundColor,    // picker background
    Color? dialHandColor,      // hour/minute hand
    Color? textColor,          // numbers
  }) async {
    final picked = await showTimePicker(
      context: context,
      initialTime: initialTime ?? TimeOfDay.now(),
      builder: (context, child) {
        return MediaQuery(
          data: MediaQuery.of(context).copyWith(
            alwaysUse24HourFormat: false,
          ),
          child: Theme(
            data: Theme.of(context).copyWith(
              colorScheme: ColorScheme.light(
                primary: primaryColor ?? AppColors.primary,       // header background & buttons
                onPrimary: AppColors.white,                     // header text color
                onSurface: textColor ?? AppColors.black,       // clock text color
              ),
              timePickerTheme: TimePickerThemeData(
                dayPeriodColor: AppColors.primary,
                backgroundColor: backgroundColor ?? AppColors.white,
                hourMinuteTextColor: WidgetStateColor.resolveWith((states) {
                  if (states.contains(WidgetState.selected)) {
                    return Colors.white; // selected hour/minute
                  }
                  return AppColors.primary; // unselected hour/minute
                }),
                dialHandColor: dialHandColor ?? AppColors.primary,
                entryModeIconColor: primaryColor ?? AppColors.primary,
                dayPeriodTextColor: WidgetStateColor.resolveWith((states) {
                  if (states.contains(WidgetState.selected)) {
                    return Colors.white; // selected AM/PM
                  }
                  return AppColors.primary; // unselected AM/PM
                }),
              ),
            ),
            child: child!,
          ),
        );
      },
    );

    if (picked == null) return null;

    // Optional min-time validation
    if (minTime != null && !_isAfter(picked, minTime)) {
      ToastService.show(message: 'Please select a time after ${formatTime12Hour(minTime)} ${minTime.hour >= 12 ? "PM" : "AM"}',isError: true);
      return null;
    }

    return picked;
  }

  static bool _isAfter(TimeOfDay selected, TimeOfDay min) {
    return selected.hour > min.hour ||
        (selected.hour == min.hour && selected.minute > min.minute);
  }
}
