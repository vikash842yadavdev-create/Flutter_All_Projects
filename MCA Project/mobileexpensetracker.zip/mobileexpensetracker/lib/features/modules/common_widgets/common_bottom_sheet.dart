import 'package:flutter/material.dart';

class BottomSheetController {
  // --- Singleton setup ---
  BottomSheetController._internal();
  static final BottomSheetController _instance =
      BottomSheetController._internal();
  factory BottomSheetController() => _instance;

  // Track all open bottom sheets
  final List<Future<dynamic>> _openSheets = [];

  /// Common reusable modal bottom sheet
  Future<dynamic> showCommonSheet({
    required BuildContext context,
    required Widget sheetContent,
    String? cancelIcon,
    double? iconPadding,
    Color? sheetColor,
    double? topBorderRadius,
    bool isDismissible = false,
    bool enableDrag = false,
    bool canPop = false,
    bool isHideCancelButton = false,
  }) {
    final sheetFuture = showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      enableDrag: enableDrag,
      isDismissible: isDismissible,
      builder: (BuildContext context) {
        return LayoutBuilder(
          builder: (BuildContext context, BoxConstraints constraints) {
            return PopScope(
              canPop: canPop,
              child: GestureDetector(
                onTap: () => FocusScope.of(context).unfocus(),
                child: Padding(
                  padding: EdgeInsets.only(
                    top: constraints.maxHeight * 0.1,
                    bottom: MediaQuery.of(context).viewInsets.bottom,
                  ),
                  child: Container(
                    decoration: BoxDecoration(
                      color: sheetColor ?? Colors.white,
                      borderRadius: BorderRadius.vertical(
                        top: Radius.circular(topBorderRadius ?? 16),
                      ),
                    ),
                    child: SafeArea(
                      bottom: true,
                      child: Stack(
                        children: [
                          SingleChildScrollView(child: sheetContent),
                          if (!isHideCancelButton)
                            Positioned(
                              right: 10,
                              top: 10,
                              child: GestureDetector(
                                onTap: () => Navigator.pop(context),
                                child: Padding(
                                  padding: EdgeInsets.all(iconPadding ?? 0),
                                  child: Icon(
                                    Icons.cancel_outlined,
                                    size: 30,
                                    color: Colors.black,
                                  ),
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            );
          },
        );
      },
    );

    // Track the sheet
    _openSheets.add(sheetFuture);

    // Remove when closed
    sheetFuture.whenComplete(() {
      _openSheets.remove(sheetFuture);
    });

    return sheetFuture;
  }

  /// Close all currently open sheets
  Future<void> closeAllSheets(BuildContext context) async {
    // Pop until all modal sheets are closed
    while (Navigator.of(context, rootNavigator: true).canPop()) {
      Navigator.of(context, rootNavigator: true).pop();
    }
    _openSheets.clear();
  }

  /// Returns true if any sheet is currently open
  bool get hasOpenSheets => _openSheets.isNotEmpty;
}
