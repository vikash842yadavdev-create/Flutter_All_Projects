import 'package:flutter/material.dart';

class NoSplashScrollBehavior extends ScrollBehavior {
  @override
  Widget buildOverscrollIndicator(
    BuildContext context,
    Widget child,
    ScrollableDetails details,
  ) {
    return child; // Removes the glow/splash effect
  }
}
