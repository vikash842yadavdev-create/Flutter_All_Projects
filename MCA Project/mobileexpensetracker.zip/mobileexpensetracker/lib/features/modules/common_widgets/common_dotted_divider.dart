import 'package:flutter/material.dart';

class CommonDottedDivider extends StatelessWidget {
  final double dashWidth;
  final double dashGap;
  final double dashHeight;
  final Color color;
  final Axis direction;

  const CommonDottedDivider({
    super.key,
    this.dashWidth = 6.0,
    this.dashGap = 4.0,
    this.dashHeight = 1.0,
    this.color = Colors.black,
    this.direction = Axis.horizontal,
  });

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final totalLength = direction == Axis.horizontal
            ? constraints.maxWidth
            : constraints.maxHeight;
        final dashCount = (totalLength / (dashWidth + dashGap))
            .floor(); // number of dashes

        return Flex(
          direction: direction,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: List.generate(dashCount, (_) {
            return SizedBox(
              width: direction == Axis.horizontal ? dashWidth : dashHeight,
              height: direction == Axis.horizontal ? dashHeight : dashWidth,
              child: DecoratedBox(decoration: BoxDecoration(color: color)),
            );
          }),
        );
      },
    );
  }
}
