
import 'package:flutter/material.dart';
import 'package:mobileexpensetracker/features/config/helper.dart';
import 'package:mobileexpensetracker/features/modules/common_widgets/common_text_field.dart';
import 'package:mobileexpensetracker/features/modules/common_widgets/country_code_picker/countries_list.dart';

class CommonCountryPickerBottomSheet extends StatefulWidget {
  const CommonCountryPickerBottomSheet({super.key});

  @override
  State<CommonCountryPickerBottomSheet> createState() =>
      _CommonCountryPickerBottomSheetState();
}

class _CommonCountryPickerBottomSheetState
    extends State<CommonCountryPickerBottomSheet> {
  List<Country> filterCountryList = [];
  bool isSearch = false;
  TextEditingController countryController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: context.width,
      decoration: BoxDecoration(
        // color: AppColors.primaryLight,
        borderRadius: BorderRadius.only(
          topRight: Radius.circular(15),
          topLeft: Radius.circular(15),
        ),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 15),
      child: Column(
        children: [
          4.pixelH,
          Container(
            width: 50,
            height: 5,
            margin: const EdgeInsets.symmetric(vertical: 15),
            decoration: const BoxDecoration(
              // color: AppColors.lightBlackColor,
              borderRadius: BorderRadius.all(Radius.circular(15)),
            ),
          ),
          Text(
            "Select Country",
            style: context.appTextTheme.headlineMedium?.copyWith(
              // fontFamily: AppConstants.chillaxRegular,
              fontSize: 22,
              fontWeight: FontWeight.w600,
            ),
          ),
          10.pixelH,
          CommonTextField(
            controller: countryController,
            borderRadius: 35,
            onChanged: searchCountry,
            prefixIcon: const Padding(
              padding: EdgeInsets.only(left: 10),
              // child: Icon(Icons.search, color: AppColors.primary),
            ),
            suffixIcon: countryController.text.isNotEmpty
                ? InkWell(
                    onTap: () {
                      countryController.clear();
                      searchCountry("");
                    },
                    child: const Padding(
                      padding: EdgeInsets.only(right: 10),
                      // child: Icon(Icons.clear, color: AppColors.black),
                    ),
                  )
                : null,
            hintText: "Search Country",
          ),
          10.pixelH,
          Expanded(
            child: ListView.builder(
              itemCount: isSearch
                  ? filterCountryList.length
                  : allCountries.length,
              itemBuilder: (context, index) {
                final country = isSearch
                    ? filterCountryList[index]
                    : allCountries[index];
                return ListTile(
                  leading: SizedBox(
                    width: context.width * .7,
                    child: Text(
                      country.name ?? "",
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: context.appTextTheme.headlineSmall?.copyWith(
                        fontSize: 20,
                      ),
                    ),
                  ),

                  // title: Text(
                  //   country.name ?? "",
                  //   style: context.appTextTheme.headlineSmall
                  //       ?.copyWith(fontSize: 20),
                  // ),
                  trailing: Text(
                    country.dialCode ?? "",
                    style: context.appTextTheme.headlineSmall?.copyWith(
                      fontSize: 16,
                    ),
                  ),
                  onTap: () {
                    // back(context,result: country);
                    Navigator.pop(context, country);
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  void searchCountry(String data) {
    logConsole(data);
    if (data.trim().isEmpty) {
      isSearch = false;
    } else {
      isSearch = true;
      filterCountryList.clear();
      var countryList = _searchCountryByName(data);
      filterCountryList.addAll(countryList);
    }
    setState(() {});
  }

  List<Country> _searchCountryByName(String data) {
    List<Country> searchedList = [];
    searchedList = allCountries.where((element) {
      return element.name!.toLowerCase().contains(data.toLowerCase()) ||
          element.code!.toLowerCase().contains(data.toLowerCase()) ||
          element.dialCode!.toLowerCase().contains(data.toLowerCase());
    }).toList();

    searchedList.sort((a, b) {
      if (a.dialCode == data) return -1;
      if (b.dialCode == data) return 1;
      return 0;
    });
    searchedList.sort((a, b) {
      if (a.name == data) return -1;
      if (b.name == data) return 1;
      return 0;
    });

    return searchedList;
  }
}
