
import 'package:flutter/material.dart';
import 'package:mobileexpensetracker/features/config/helper.dart';

class CommonAppBar extends StatelessWidget {
  final String title;
  final Widget? actionWidget;
  final Widget? leadingWidget;
  final bool centerTitle;

  const CommonAppBar({
    super.key,
    required this.title,
    this.leadingWidget,
    this.centerTitle = false, this.actionWidget,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 25, horizontal: 20),
      width: context.width,
      decoration: BoxDecoration(
        color: AppColors.white,
        boxShadow: [
          BoxShadow(
            color: AppColors.black.withValues(alpha: 0.12),
            blurRadius: 10,
            offset: Offset(0, 1),
          ),
        ],
      ),
      child: SafeArea(
        child: SizedBox(
          height: 40, // consistent height
          child: Stack(
            alignment: Alignment.center,
            children: [

              if (leadingWidget != null)
                Align(
                  alignment: Alignment.centerLeft,
                  child:leadingWidget!,
                ),
              /// CENTER / LEFT TITLE
              Align(
                alignment:
                centerTitle || leadingWidget != null ? Alignment.center : Alignment.centerLeft,
                child: Text(
                  title,
                  style: context.appTextTheme.headlineLarge?.copyWith(
                    fontWeight: FontWeight.w700,
                    fontSize: 32,
                  ),
                ),
              ),

              /// RIGHT ACTION WIDGET
              if (actionWidget != null)
                Align(
                  alignment: Alignment.centerRight,
                  child: actionWidget!,
                ),
            ],
          ),
        ),
      ),
    );
  }
}

