import 'package:flutter/material.dart';

enum DotStyle { dash, round }

class DottedDivider extends StatelessWidget {
  final double height;
  final double spacing;
  final double radius;
  final Color color;
  final DotStyle dotStyle;

  const DottedDivider({
    super.key,
    this.height = 1,
    this.spacing = 4,
    this.radius = 2,
    this.color = Colors.grey,
    this.dotStyle = DotStyle.round,
  });

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: _DottedLinePainter(
        spacing: spacing,
        radius: radius,
        color: color,
        dotStyle: dotStyle,
      ),
      size: Size(double.infinity, height),
    );
  }
}

class _DottedLinePainter extends CustomPainter {
  final double spacing;
  final double radius;
  final Color color;
  final DotStyle dotStyle;

  _DottedLinePainter({
    required this.spacing,
    required this.radius,
    required this.color,
    required this.dotStyle,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.fill;

    double startX = 0;
    final centerY = size.height / 2;

    while (startX < size.width) {
      if (dotStyle == DotStyle.round) {
        canvas.drawCircle(Offset(startX, centerY), radius, paint);
      } else if (dotStyle == DotStyle.dash) {
        final dashWidth = radius * 2;
        canvas.drawRect(
          Rect.fromLTWH(startX, centerY - radius / 2, dashWidth, radius),
          paint,
        );
      }
      startX += spacing + radius * 2;
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
