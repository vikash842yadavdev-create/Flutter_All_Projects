import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:mobileexpensetracker/features/config/helper.dart';

import '../common_widgets/common_image_widget.dart';

// class LoaderManager {
//   /// Displays a dialog with an image using vanilla Flutter (no GetX).
//   static Future<void> showImageDialog({
//     required BuildContext context,
//     required String imageUrl,
//   }) async {
//     showGeneralDialog(
//       context: context,
//       barrierDismissible: true,
//       barrierLabel: "ImageDialog",
//       transitionDuration: const Duration(milliseconds: 500),
//       pageBuilder: (_, __, ___) => Center(
//         child: CommonImageWidget(
//           height: MediaQuery.of(context).size.width * 0.85,
//           width: MediaQuery.of(context).size.width * 0.85,
//           img: imageUrl,
//           imageRadius: 1500,
//         ),
//       ),
//       transitionBuilder: (context, animation, secondaryAnimation, child) {
//         return FadeTransition(opacity: animation, child: child);
//       },
//     );
//   }
//
//   /// Show a loading dialog
//   static Future<void> showLoading(BuildContext context) async {
//     showDialog(
//       context: context,
//       barrierDismissible: false,
//       barrierColor: Colors.black.withOpacity(0.1),
//       builder: (_) => BackdropFilter(
//         filter: ImageFilter.blur(sigmaX: 4, sigmaY: 4),
//         child: Dialog(
//           backgroundColor: Colors.transparent,
//           surfaceTintColor: Colors.transparent,
//           child: Container(
//             decoration: const BoxDecoration(
//               color: AppColor
//                   .transparent, // replace with your AppColors.kPrimaryColor
//               shape: BoxShape.circle,
//             ),
//             child: const Stack(
//               alignment: Alignment.center,
//               children: [
//                 SizedBox(
//                   width: 100,
//                   height: 100,
//                   child: CircularProgressIndicator(
//                     color: AppColor.primary,
//
//                     // replace with AppColors.lightPinkColor
//                   ),
//                 ),
//                 CommonImageWidget(
//                   img: Assets.loaderIcon, // replace with AppImages.icAppLogo
//                   width: 70,
//                   fit: BoxFit.contain,
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
//
//   /// Close dialog (if needed externally)
//   static void closeLoading(BuildContext context) {
//     Navigator.of(context, rootNavigator: true).maybePop();
//   }
// }

class LoaderManager {
  static final LoaderManager _instance = LoaderManager._internal();

  factory LoaderManager() => _instance;

  LoaderManager._internal();

  bool _isShowing = false;

  /// Global key to access context without passing it
  static final GlobalKey<NavigatorState> navigatorKey =
      GlobalKey<NavigatorState>();

  void showLoading() {
    if (_isShowing) return;

    SchedulerBinding.instance.addPostFrameCallback((timeStamp) {
      Future.delayed(Duration.zero).then((value) {
        final context = navigatorKey.currentContext;
        if (context == null) return;
        if (_isShowing) {
          logConsole("already opened", tag: "showLoading");
          return;
        }
        _isShowing = true;
        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (context) {
            return Center(child: _LoaderWidget());
          },
        ).whenComplete(() {
          _isShowing = false;
        });
      });
    });
  }

  void closeLoading() {
    if (_isShowing) {
      final context = navigatorKey.currentContext;
      if (context == null) return;
      Navigator.pop(context);
      _isShowing = false;
    }
  }

  bool get isShowing => _isShowing;
}

class _LoaderWidget extends StatelessWidget {
  const _LoaderWidget();

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 2, sigmaY: 2),
        child: Dialog(
          backgroundColor: AppColors.transparent,
          elevation: 0,
          surfaceTintColor: AppColors.transparent,
          child: Container(
            padding: EdgeInsets.all(4),
            decoration: BoxDecoration(
              color: AppColors.white,
              shape: BoxShape.circle,
            ),
            child: const Stack(
              alignment: Alignment.center,
              children: [
                SizedBox(
                  width: 80,
                  height: 80,
                  child: CircularProgressIndicator(
                    // backgroundColor: AppColors.kPrimaryColor,
                    color: AppColors.primary,
                  ),
                ),
                // CommonImageWidget(
                //   img: Assets.icNextButton,
                //   width: 38,
                //   height: 38,
                //   svgColorFilter: AppColors.kPrimaryColor,
                // ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
