
import 'package:fluttertoast/fluttertoast.dart';

import '../../config/helper.dart';

// void toast({required String? msg, bool isError = false}) {
//   if (msg == "null") {
//     msg = "";
//     logConsole("toast dismissed as msg was null");
//   }
//
//   if (msg?.isNotEmpty ?? false) {
//     try {
//       Fluttertoast.cancel();
//       Fluttertoast.showToast(
//         msg: msg ?? "",
//         backgroundColor: AppColors.black,
//         textColor: AppColors.white,
//         toastLength: isError ? Toast.LENGTH_LONG : Toast.LENGTH_SHORT,
//         fontSize: 16,
//         gravity: ToastGravity.BOTTOM,
//         fontAsset: "assets/fonts/Montserrat-Regular.ttf",
//       );
//     } catch (e) {
//       logConsole(e);
//     }
//   }
// }

class ToastService {
  static void show({String? message, bool isError = false}) {
    if (message == "null" || message == null) {
      message = "";
      logConsole("toast dismissed as msg was null");
    }
    Fluttertoast.cancel();
    if (message.isEmpty) return;
    Fluttertoast.showToast(
      msg: message,
      backgroundColor: AppColors.black,
      textColor: AppColors.white,
      toastLength: isError ? Toast.LENGTH_LONG : Toast.LENGTH_SHORT,
      fontSize: 16,
      gravity: ToastGravity.BOTTOM,
      fontAsset: "assets/fonts/Oxanium-Regular.ttf",
    );
  }
}
