

import 'package:flutter/material.dart';
import 'package:mobileexpensetracker/features/config/assets.dart' show Assets;
import 'package:mobileexpensetracker/features/modules/common_widgets/common_image_widget.dart';

class CommonBackButton extends StatelessWidget {
  final VoidCallback ontap;
  final EdgeInsets? padding;
  const CommonBackButton({super.key, required this.ontap, this.padding});

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.centerLeft,
      child: InkWell(
        onTap: ontap,borderRadius: BorderRadius.circular(50),
        child: Padding(
          padding: padding ?? EdgeInsets.zero,
          child: CommonImageWidget(
            img: Assets.icBackArrow,
            width: 24,
            height: 24,
          ),
        ),
      ),
    );
  }
}
