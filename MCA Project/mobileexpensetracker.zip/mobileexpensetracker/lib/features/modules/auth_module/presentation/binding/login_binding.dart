import 'package:get/get.dart';
import 'package:mobileexpensetracker/features/modules/auth_module/presentation/controler/login_controller.dart';

class LoginBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<LoginController>(
      () => LoginController(),
    );
  }
}
