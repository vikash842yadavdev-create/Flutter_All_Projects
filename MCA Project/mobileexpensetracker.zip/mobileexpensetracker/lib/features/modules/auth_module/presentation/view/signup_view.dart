import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:mobileexpensetracker/features/config/assets.dart';
import 'package:mobileexpensetracker/features/config/helper.dart';
import 'package:mobileexpensetracker/features/config/routes/app_pages.dart';
import 'package:mobileexpensetracker/features/modules/common_widgets/common_button.dart';
import 'package:mobileexpensetracker/features/modules/common_widgets/common_image_widget.dart';
import 'package:mobileexpensetracker/features/modules/common_widgets/common_scaffold.dart';
import 'package:mobileexpensetracker/features/modules/common_widgets/common_text_field.dart';

class SignUpView extends StatefulWidget {
  const SignUpView({super.key});

  @override
  State<SignUpView> createState() => _SignUpViewState();
}

class _SignUpViewState extends State<SignUpView> {
  @override
  Widget build(BuildContext context) {
    return CommonScaffold(
      background: Assets.imgBackground,
      body: Center(
        child: SingleChildScrollView(
          child: Container(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  200.pixelH,
                  CommonImageWidget(
                    img: Assets.imgProfileDummy,
                    height: 120,
                    width: double.infinity,
                    fit: BoxFit.contain,
                  ),
                  Text(
                    'Welcome',
                    style: TextStyle(
                      fontSize: 36,
                      fontWeight: FontWeight.bold,
                      color: AppColors.secondary,
                    ),
                  ),
                  20.pixelH,
          
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      'Username ',
                      style: TextStyle(fontSize: 14, color: AppColors.black),
                    ),
                  ),
                  5.pixelH,
                  CommonTextField(
                    verticalPadding: 0,
                    hintText: 'user123',
                    hintTextSize: 12,
                    hintTextColor: AppColors.textfield_primary,
                    borderRadius: 8,
                  ),
                  10.pixelH,
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      'Email ',
                      style: TextStyle(fontSize: 14, color: AppColors.black),
                    ),
                  ),
                  5.pixelH,
          
                  CommonTextField(
                    verticalPadding: 0,
                    hintText: 'example@gmail.com',
                    hintTextSize: 12,
                    hintTextColor: AppColors.textfield_primary,
                    borderRadius: 8,
                  ),
                  10.pixelH,
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      'Password ',
                      style: TextStyle(fontSize: 14, color: AppColors.black),
                    ),
                  ),
                  5.pixelH,
                  CommonTextField(
                    verticalPadding: 0,
                    hintText: '********',
                    hintTextSize: 12,
                    hintTextColor: AppColors.textfield_primary,
                    borderRadius: 8,
                  ),
                  10.pixelH,
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      'Confirm Password ',
                      style: TextStyle(fontSize: 14, color: AppColors.black),
                    ),
                  ),
                  5.pixelH,
                  CommonTextField(
                    verticalPadding: 0,
          
                    hintText: '********',
                    hintTextSize: 12,
                    hintTextColor: AppColors.textfield_primary,
                    borderRadius: 8,
                  ),
                  20.pixelH,
                  CommonButton(
                    text: 'Sign Up',
                    textSize: 16,
          
                    ontap: () {},
                    isGradient: true,
                    isShadow: true,
                  ),
                  20.pixelH,
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        "Already have account?",
                        style: TextStyle(fontSize: 14, color: AppColors.black),
                      ),
                      5.pixelW,
                      InkWell(
                        onTap: () {
                          // Navigate to the login screen
                          Get.offNamed(Routes.loginView);
                        },
                        child: Text(
                          "Log In",
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            color: AppColors.secondary,
                            height: 1,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
