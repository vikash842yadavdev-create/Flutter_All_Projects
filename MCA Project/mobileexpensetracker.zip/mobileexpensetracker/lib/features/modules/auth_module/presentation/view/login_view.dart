import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:mobileexpensetracker/features/config/assets.dart';
import 'package:mobileexpensetracker/features/config/helper.dart';
import 'package:mobileexpensetracker/features/config/routes/app_pages.dart';
import 'package:mobileexpensetracker/features/modules/common_widgets/common_button.dart';
import 'package:mobileexpensetracker/features/modules/common_widgets/common_image_widget.dart';
import 'package:mobileexpensetracker/features/modules/common_widgets/common_scaffold.dart';
import 'package:mobileexpensetracker/features/modules/common_widgets/common_text_field.dart';

class LoginView extends StatefulWidget {
  const LoginView({super.key});

  @override
  State<LoginView> createState() => _LoginViewState();
}

class _LoginViewState extends State<LoginView> {
  @override
  Widget build(BuildContext context) {
    return CommonScaffold(
      background: Assets.imgBackground,
      body: Center(
        child: Container(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  CommonImageWidget(
                    img: Assets.imgProfileDummy,
                    height: 120,
                    width: double.infinity,
                    fit: BoxFit.contain,
                  ),
                  Text(
                    'Welcome',
                    style: TextStyle(
                      fontSize: 36,
                      fontWeight: FontWeight.bold,
                      color: AppColors.secondary,
                    ),
                  ),
                  20.pixelH,
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      'Email ',
                      style: TextStyle(fontSize: 14, color: AppColors.black),
                    ),
                  ),
                  5.pixelH,

                  CommonTextField(
                    verticalPadding: 0,
                    hintText: 'example@gmail.com',
                    hintTextSize: 12,
                    hintTextColor: AppColors.textfield_primary,
                    borderRadius: 8,
                  ),
                  10.pixelH,
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      'Password ',
                      style: TextStyle(fontSize: 14, color: AppColors.black),
                    ),
                  ),
                  5.pixelH,
                  CommonTextField(
                    verticalPadding: 0,
                    hintText: '********',
                    hintTextSize: 12,
                    hintTextColor: AppColors.textfield_primary,
                    borderRadius: 8,
                  ),
                  20.pixelH,
                  CommonButton(
                    text: 'Log In',
                    textSize: 16,

                    ontap: () {
                      Get.offNamed(Routes.mainView);
                    },
                    isGradient: true,
                    isShadow: true,
                  ),
                  20.pixelH,
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        "Don't have an account?",
                        style: TextStyle(fontSize: 14, color: AppColors.black),
                      ),
                      5.pixelW,
                      InkWell(
                        onTap: () {
                          // Navigate to the signup screen

                          Get.toNamed(Routes.signUpView);
                        },
                        child: Text(
                          "Sign Up",
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            color: AppColors.secondary,
                            height: 1,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
