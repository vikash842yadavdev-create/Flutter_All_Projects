import 'package:get/get.dart';

class SignUpController extends GetxController {
  // Add any necessary state variables and methods for signup logic here
}
