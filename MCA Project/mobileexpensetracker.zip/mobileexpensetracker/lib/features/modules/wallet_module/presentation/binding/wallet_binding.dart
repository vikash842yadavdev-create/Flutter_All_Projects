import 'package:get/get.dart';
import 'package:mobileexpensetracker/features/modules/wallet_module/presentation/controller/wallet_controller.dart';

class WalletBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<WalletController>(() => WalletController());
  }
}
