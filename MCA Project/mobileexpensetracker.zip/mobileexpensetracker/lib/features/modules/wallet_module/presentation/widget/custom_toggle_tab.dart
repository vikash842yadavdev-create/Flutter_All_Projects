import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controller/wallet_controller.dart';

class CustomToggleTab extends GetView<WalletController> {
  const CustomToggleTab({super.key});

  @override
  Widget build(BuildContext context) {
    final tabs = ["Transactions", "Upcoming Bills"];

    return Obx(
      () => Container(
        height: 50,
        padding: const EdgeInsets.all(4),
        decoration: BoxDecoration(
          color: Colors.grey.shade200,
          borderRadius: BorderRadius.circular(30),
        ),
        child: Row(
          children: List.generate(
            tabs.length,
            (index) => Expanded(
              child: GestureDetector(
                onTap: () => controller.changeTab(index),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 250),
                  curve: Curves.easeInOut,
                  decoration: BoxDecoration(
                    color: controller.selectedTab.value == index
                        ? Colors.white
                        : Colors.transparent,
                    borderRadius: BorderRadius.circular(25),
                    boxShadow: controller.selectedTab.value == index
                        ? [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.05),
                              blurRadius: 8,
                            ),
                          ]
                        : [],
                  ),
                  child: Center(
                    child: AnimatedDefaultTextStyle(
                      duration: const Duration(milliseconds: 250),
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: controller.selectedTab.value == index
                            ? const Color(0xff4E9F8E)
                            : Colors.grey,
                      ),
                      child: Text(tabs[index]),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
