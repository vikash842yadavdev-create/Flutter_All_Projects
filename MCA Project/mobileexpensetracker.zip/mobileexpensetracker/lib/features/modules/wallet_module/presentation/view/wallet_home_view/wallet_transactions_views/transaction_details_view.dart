import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:mobileexpensetracker/features/config/assets.dart';
import 'package:mobileexpensetracker/features/config/helper.dart';
import 'package:mobileexpensetracker/features/modules/common_widgets/common_small_widgets/custom_headerbar_widget.dart';
import 'package:mobileexpensetracker/features/modules/common_widgets/common_text_widget.dart';
import 'package:mobileexpensetracker/features/modules/wallet_module/data/models/wallet_item_model.dart';
import 'package:mobileexpensetracker/features/modules/wallet_module/presentation/controller/wallet_controller.dart';

class TransactionDetailsView extends StatefulWidget {
  final WalletItemModel item;

  const TransactionDetailsView({super.key, required this.item});

  @override
  State<TransactionDetailsView> createState() => _TransactionDetailsViewState();
}

class _TransactionDetailsViewState extends State<TransactionDetailsView> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage(Assets.imgBackground2),
            fit: BoxFit.cover,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            children: [
              40.pixelH,
              CustomHeaderBar(
                onLeadingTap: () {
                  Get.find<WalletController>().currentView.value =
                      WalletAllView.walletHomeView;
                },
                title: "Transaction Details",
                actionIcon: Icons.more_horiz,
              ),
              30.pixelH,

              CircleAvatar(
                backgroundColor: AppColors.transparent,
                radius: 40,
                backgroundImage: AssetImage(widget.item.image),
              ),
              12.pixelH,

              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 6,
                ),

                decoration: BoxDecoration(
                  color: widget.item.isIncome
                      ? Colors.green.shade50
                      : Colors.red.shade50,

                  borderRadius: BorderRadius.circular(20),
                ),

                child: CommonText(widget.item.status, fontSize: 12),
              ),
              8.pixelH,

              Text(
                widget.item.amount,
                style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              27.pixelH,

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  CommonText(
                    "Transaction details",
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                  Icon(Icons.keyboard_arrow_up),
                ],
              ),
              15.pixelH,

              Column(
                children: [
                  _row(
                    "Status",
                    widget.item.status,
                    widget.item.isIncome ? Colors.green : Colors.red,
                  ),

                  _row(
                    widget.item.isIncome ? "From" : "To",
                    widget.item.personName,
                  ),

                  _row("Time", widget.item.time),

                  _row("Date", widget.item.date),
                ],
              ),
              8.pixelH,
              const Divider(),
              8.pixelH,

              Column(
                children: [
                  _row(
                widget.item.isIncome ? "Earnings" : "Spending",
                widget.item.amount,
              ),

              _row("Fee", "- ${widget.item.fee}"),

                ],
              ),
              8.pixelH,

              const Divider(),
              8.pixelH,


              _row("Total", widget.item.amount),
20.pixelH,



              SizedBox(
                width: double.infinity,
                height: 55,

                child: OutlinedButton(
                  style: OutlinedButton.styleFrom(
                    side: BorderSide(
                      color: AppColors.primary, // The color you want
                      width: 1, // Optional: thickness of the border
                    ),
                  ),
                  onPressed: () {},

                  child: const Text(
                    "Download Receipt",
                    style: TextStyle(color: AppColors.secondary),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

Widget _row(String title, String value, [Color? color]) {
  return Padding(
    padding: const EdgeInsets.symmetric(vertical: 4),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        CommonText(title, fontSize: 14),

        Text(
          value,
          style: TextStyle(color: color, fontWeight: FontWeight.w600),
        ),
      ],
    ),
  );
}
