import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:mobileexpensetracker/features/modules/wallet_module/presentation/controller/wallet_controller.dart';
import 'package:mobileexpensetracker/features/modules/wallet_module/presentation/view/wallet_home_view/wallet_bill_views/bill_detail_view.dart';
import 'package:mobileexpensetracker/features/modules/wallet_module/presentation/view/wallet_home_view/wallet_bill_views/bill_payment_view.dart';
import 'package:mobileexpensetracker/features/modules/wallet_module/presentation/view/wallet_home_view/wallet_bill_views/paymentsuccess_view.dart';
import 'package:mobileexpensetracker/features/modules/wallet_module/presentation/view/wallet_home_view/wallet_home_view.dart';
import 'package:mobileexpensetracker/features/modules/wallet_module/presentation/view/wallet_home_view/wallet_transactions_views/transaction_details_view.dart';

class WalletMainView extends StatefulWidget {
  const WalletMainView({super.key});

  @override
  State<WalletMainView> createState() => _WalletMainViewState();
}

class _WalletMainViewState extends State<WalletMainView> {
  @override
  Widget build(BuildContext context) {
    final WalletController controller = Get.put(WalletController());
    return Obx(() {
      switch (controller.currentView.value) {
        case WalletAllView.walletHomeView:
          return const WalletHomeView();

        case WalletAllView.transactionDetailView:
          return TransactionDetailsView(
            item: controller.selectedTransaction.value!,
          );

        case WalletAllView.billDetailView:
          return BillDetailView(item: controller.selectedBill.value!);

        case WalletAllView.billPaymentView:
          return BillPaymentView(
            item: controller.selectedBill.value!
          );

        case WalletAllView.paymentSuccessView:
          return PaymentsuccessView(
            item: controller.selectedBill.value!,
          );
      }
    });
  }
}
