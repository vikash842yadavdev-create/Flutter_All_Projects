import 'package:get/get.dart';

class PaymentController extends GetxController {
  RxInt selectedIndex = 0.obs;

  void selectMethod(int index) {
    selectedIndex.value = index;
  }
}
