import 'package:get/get.dart';
import 'package:mobileexpensetracker/features/modules/wallet_module/data/models/wallet_item_model.dart';
import 'package:mobileexpensetracker/features/modules/wallet_module/presentation/controller/wallet_controller.dart';

class TransactionDetailsController extends GetxController {
  late WalletItemModel transaction;

  @override
  void onInit() {
    super.onInit();
    transaction = Get.find<WalletController>().selectedTransaction.value!;
  }
}
