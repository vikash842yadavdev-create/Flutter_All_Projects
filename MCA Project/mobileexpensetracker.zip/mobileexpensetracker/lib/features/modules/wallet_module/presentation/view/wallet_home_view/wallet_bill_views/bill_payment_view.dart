import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:mobileexpensetracker/features/config/assets.dart';
import 'package:mobileexpensetracker/features/config/helper.dart';
import 'package:mobileexpensetracker/features/modules/common_widgets/common_button.dart';
import 'package:mobileexpensetracker/features/modules/common_widgets/common_small_widgets/custom_headerbar_widget.dart';
import 'package:mobileexpensetracker/features/modules/common_widgets/common_text_widget.dart';
import 'package:mobileexpensetracker/features/modules/wallet_module/data/models/bill_model.dart';
import 'package:mobileexpensetracker/features/modules/wallet_module/presentation/controller/wallet_controller.dart';

class BillPaymentView extends StatefulWidget {
  final BillModel item;
  const BillPaymentView({super.key, required this.item});

  @override
  State<BillPaymentView> createState() => _BillPaymentViewState();
}

class _BillPaymentViewState extends State<BillPaymentView> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage(Assets.imgBackground2),
            fit: BoxFit.cover,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            children: [
              40.pixelH,
              CustomHeaderBar(
                onLeadingTap: () {
                  Get.find<WalletController>().currentView.value =
                      WalletAllView.billDetailView;
                },
                title: "Bill Payment",
                actionIcon: Icons.more_horiz,
              ),
              50.pixelH,
              CircleAvatar(
                backgroundColor: AppColors.transparent,
                radius: 40,
                backgroundImage: AssetImage(widget.item.image),
              ),
              12.pixelH,
              RichText(
                textAlign: TextAlign.center,
                text: TextSpan(
                  style: const TextStyle(
                    fontSize: 20,
                    color: Colors.black,
                    height: 1.5,
                  ),
                  children: [
                    const TextSpan(text: "You will pay "),
                    TextSpan(
                      text: widget.item.title,
                      style: TextStyle(
                        color: AppColors.primary,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const TextSpan(text: "\nfor one month with BCA OneKlik"),
                  ],
                ),
              ),
              45.pixelH,

              _row("Price", widget.item.price.toString()),
              _row("Fee", widget.item.fee.toString()),
              5.pixelH,
              Divider(),
              5.pixelH,

              _row("Total", widget.item.total.toString()),
              30.pixelH,

              Spacer(),
              CommonButton(
                text: "Pay Now",
                ontap: () {
                    Get.find<WalletController>().currentView.value =
                      WalletAllView.paymentSuccessView;
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

Widget _row(String title, String value, [Color? color]) {
  return Padding(
    padding: const EdgeInsets.symmetric(vertical: 4),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        CommonText(title, fontSize: 14),

        Text(
          value,
          style: TextStyle(color: color, fontWeight: FontWeight.w600),
        ),
      ],
    ),
  );
}
