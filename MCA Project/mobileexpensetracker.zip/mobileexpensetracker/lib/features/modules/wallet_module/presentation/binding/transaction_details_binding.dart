import 'package:get/get.dart';
import 'package:mobileexpensetracker/features/modules/wallet_module/presentation/controller/transaction_details_controller.dart';

class TransactionDetailsBinding extends Bindings {
  @override
  void dependencies() {
    // TODO: implement dependencies
    Get.lazyPut<TransactionDetailsController>(
      () => TransactionDetailsController(),
    );
  }
}
