import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:mobileexpensetracker/features/config/assets.dart';
import 'package:mobileexpensetracker/features/config/helper.dart';
import 'package:mobileexpensetracker/features/modules/common_widgets/common_small_widgets/custom_headerbar_widget.dart';
import 'package:mobileexpensetracker/features/modules/common_widgets/common_text_widget.dart';
import 'package:mobileexpensetracker/features/modules/wallet_module/presentation/controller/wallet_controller.dart';
import 'package:mobileexpensetracker/features/modules/wallet_module/presentation/widget/action_item_widget.dart';
import 'package:mobileexpensetracker/features/modules/wallet_module/presentation/widget/bill_item_tile.dart';
import 'package:mobileexpensetracker/features/modules/wallet_module/presentation/widget/custom_toggle_tab.dart';
import 'package:mobileexpensetracker/features/modules/wallet_module/presentation/widget/wallet_item_tile.dart';

class WalletHomeView extends StatefulWidget {
  const WalletHomeView({super.key});

  @override
  State<WalletHomeView> createState() => _WalletViewState();
}

class _WalletViewState extends State<WalletHomeView> {
  @override
  Widget build(BuildContext context) {
    final WalletController controller = Get.put(WalletController());
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage(Assets.imgBackground2),
            fit: BoxFit.cover,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            children: [
              40.pixelH,
              CustomHeaderBar(
                title: "Wallet",
                actionIcon: Icons.notifications_outlined,
              ),
              40.pixelH,
              CommonText("Total Balance", fontSize: 16, color: Colors.grey),
              5.pixelH,
              CommonText(
                "\$ 2,548.00",
                fontSize: 30,
                color: AppColors.black,
                fontWeight: FontWeight.bold,
              ),
              30.pixelH,
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 30),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    ActionItemWidget(
                      icon: Icons.add,
                      title: "Add",
                      onTap: () {},
                      iconSize: 40,
                    ),
                    ActionItemWidget(
                      icon: Icons.qr_code,
                      title: "Pay",
                      onTap: () {},
                      iconSize: 30,
                    ),
                    ActionItemWidget(
                      icon: Icons.telegram_sharp,
                      title: "Send",
                      onTap: () {},
                      iconSize: 40,
                    ),
                  ],
                ),
              ),
              45.pixelH,
              CustomToggleTab(),
              Expanded(
                child: Obx(() {
                  if (controller.selectedTab.value ==
                      WalletController.transactionsTab) {
                    return ListView.builder(
                      itemCount: controller.transactions.length,
                      itemBuilder: (context, index) {
                        return WalletItemTile(
                          item: controller.transactions[index],
                        );
                      },
                    );
                  }

                  return ListView.builder(
                    itemCount: controller.upcomingBills.length,
                    itemBuilder: (context, index) {
                      return BillItemTile(
                        bill: controller.upcomingBills[index],
                      );
                    },
                  );
                }),
              )
            ],
          ),
        ),
      ),
    );
  }
}
