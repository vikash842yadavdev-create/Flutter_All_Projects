class BillModel {
   final String id;
  final String title;
  final String image;
  final String dueDate;

  final double price;
  final double fee;
  final double total;

  final String paymentMethod;
  final String status;

  final String? transactionId;
  final String? paymentTime;
  final String? paymentDate;

  BillModel({
    required this.id,
    required this.title,
    required this.image,
    required this.dueDate,
    required this.price,
    required this.fee,
    required this.total,
    required this.paymentMethod,
    required this.status,
    this.transactionId,
    this.paymentTime,
    this.paymentDate,
  });

//   factory BillModel.fromJson(Map<String, dynamic> json) {
//     return BillModel(
//       id: json['id'] ?? '',
//       title: json['title'] ?? '',
//       image: json['image'] ?? '',
//       dueDate: json['dueDate'] ?? '',
//       price: (json['price'] ?? 0).toDouble(),
//       fee: (json['fee'] ?? 0).toDouble(),
//       total: (json['total'] ?? 0).toDouble(),
//       paymentMethod: json['paymentMethod'] ?? '',
//       status: json['status'] ?? '',
//       transactionId: json['transactionId'] ?? '',
//       paymentTime: json['paymentTime'] ?? '',
//       paymentDate: json['paymentDate'] ?? '',
//     );
//   }

//   Map<String, dynamic> toJson() {
//     return {
//       'id': id,
//       'title': title,
//       'image': image,
//       'dueDate': dueDate,
//       'price': price,
//       'fee': fee,
//       'total': total,
//       'paymentMethod': paymentMethod,
//       'status': status,
//       'transactionId': transactionId,
//       'paymentTime': paymentTime,
//       'paymentDate': paymentDate,
//     };
//   }
}
