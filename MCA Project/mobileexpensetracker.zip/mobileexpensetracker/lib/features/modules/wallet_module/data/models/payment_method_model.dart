import 'package:flutter/material.dart';

class PaymentMethodModel {
  final String title;
  final IconData icon;

  PaymentMethodModel({required this.title, required this.icon});
}
