class WalletItemModel {
  final String title;
  final String subtitle;
  final String image;
  final String amount;
  final bool isIncome;

  final String status;
  final String personName;
  final String time;
  final String date;
  final String fee;

  WalletItemModel({
    required this.title,
    required this.subtitle,
    required this.image,
    required this.amount,
    this.isIncome = false,
    required this.status,
    required this.personName,
    required this.time,
    required this.date,
    required this.fee,
  });
}


// WalletItemModel.fromJson(Map<String, dynamic> json)
// Map<String, dynamic> toJson()
