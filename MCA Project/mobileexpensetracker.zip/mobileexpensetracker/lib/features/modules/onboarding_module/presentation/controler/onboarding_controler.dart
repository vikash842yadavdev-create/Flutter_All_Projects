import 'package:get/get.dart';

class OnboardingController extends GetxController {
  // Add any necessary state variables and methods for onboarding logic here
}
