import 'package:get/get.dart';
import 'package:mobileexpensetracker/features/modules/onboarding_module/presentation/controler/splash_controller.dart';

class SplashBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<SplashController>(() => SplashController());
  }
}
